import hashlib
import json
from typing import Dict, Any

from flask import Flask, request

# settings
SIGNING_SECRET = b"W1mdtlLBg3Ox38eut-3uAaiX9dcTZcVd"
HOST = "0.0.0.0"
PORT = 19091

# event list
# ref: https://open.seatalk.io/docs/list-of-events
EVENT_VERIFICATION = "event_verification"
NEW_BOT_SUBSCRIBER = "new_bot_subscriber"
MESSAGE_FROM_BOT_SUBSCRIBER = "message_from_bot_subscriber"
INTERACTIVE_MESSAGE_CLICK = "interactive_message_click"

app = Flask(__name__)


def is_valid_signature(signing_secret: bytes, body: bytes, signature: str) -> bool:
    # ref: https://open.seatalk.io/docs/server-apis-event-callback
    return hashlib.sha256(body + signing_secret).hexdigest() == signature


@app.route("/bot-callback", methods=["POST"])
def bot_callback_handler():
    body: bytes = request.get_data()
    signature: str = request.headers.get("signature")
    # 1. validate the signature
    if not is_valid_signature(SIGNING_SECRET, body, signature):
        print("Invalid signature!")
        return ""
    # 2. handle events
    data: Dict[str, Any] = json.loads(body)
    event_type: str = data.get("event_type", "")
    print(data)
    if event_type == EVENT_VERIFICATION:
        return data.get("event")
    elif event_type == NEW_BOT_SUBSCRIBER:
        # fill with your own code
        pass
    elif event_type == MESSAGE_FROM_BOT_SUBSCRIBER:
        # fill with your own code
        pass
    elif event_type == INTERACTIVE_MESSAGE_CLICK:
        # handle interactive message click event
        pass
    else:
        pass

    return ""

if __name__ == "__main__":
    app.run(host=HOST, port=PORT, debug=True)

