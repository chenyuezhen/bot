
import requests
url = "https://queenbee.gre.garenanow.com/api/ccu/login"  # Replace with the actual API endpoint URL
headers = {
    "Content-Type": "application/json",
}

data = {
    "username": "yuezhen.chen@garena.cn",

     "password": "J7eKDHCY6PcdMxG5"

}

response = requests.post(url, headers=headers, json=data)

if response.status_code == 200:  # 假设响应状态码为200表示成功
    response_data = response.json()  # 将响应内容解析为JSON

    # 从响应数据中提取token值
    token = response_data['data']['token']

    print("Token:", token)
else:
    print("请求失败，状态码:", response.status_code)

job_headers = headers = {
    "Content-Type": "application/json",
    "Token":token,
    "currentuser": 'yuezhen.chen@garena.cn'
}

print(job_headers)
jobexec_url = "https://queenbee.gre.garenanow.com/api/v2/task/app/8/63a1652fd47a646449701814/run"

job_data = {
    "step_ids": [
    ],
    "id": "63a1652fd47a646449701814",
}

def exec_job():
    job_response = requests.post(jobexec_url, headers=job_headers, json=job_data)
    #print(job_response.json())
    #context = "fcovn is restarting, please wait patiently"
    #print(context)
    #return context
#def exec_illegal():
#    context = "抱歉,我还不能理解你当前的指令,请联系GRE开发此功能"
#    print(context)
#    return context
def exec_guide():
    context = """已支持功能:
1.CODM 测试环境更新
2.CODM 正式环境更新
3.CODM CDN预热
4.CODM CDN预热结果查询
5.FCOVN nextlive env 重启(Queenbee 平台)

其他功能陆续开发中......"""

    print(context)
    return context
if __name__ == "__main__":
    exec_job()
#    exec_illegal()
    exec_guide()
