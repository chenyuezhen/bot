# -*- coding: utf-8 -*-
import json
from typing import Dict, Any
import requests
import datetime
import re


def create_nonstop_old_recycle_task(oldrest,newrest):


