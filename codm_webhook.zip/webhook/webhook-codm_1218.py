#!/usr/local/bin/python3.7
# -*- coding: utf-8 -*-


import hashlib
import json
from typing import Dict, Any
from flask import Flask, request
import requests
import datetime
import time
import base64
import re
import cdn_prefetch
import bk_task
import fcovn_restart
import qianwen
import fco_update
# settings
SIGNING_SECRET = b"W1mdtlLBg3Ox38eut-3uAaiX9dcTZcVd"
HOST = "0.0.0.0"
PORT = 19091

# event list
# ref: https://open.seatalk.io/docs/list-of-events
EVENT_VERIFICATION = "event_verification"
NEW_BOT_SUBSCRIBER = "new_bot_subscriber"
MESSAGE_FROM_BOT_SUBSCRIBER = "message_from_bot_subscriber"
NEW_MENTIONED_MESSAGE_FROM_GROUP_CHAT = "new_mentioned_message_received_from_group_chat"
INTERACTIVE_MESSAGE_CLICK = "interactive_message_click"
app = Flask(__name__)


def is_valid_signature(signing_secret: bytes, body: bytes, signature: str) -> bool:
    return hashlib.sha256(body + signing_secret).hexdigest() == signature


def get_accesstoken_generate_header():
    url = "https://openapi.seatalk.io/auth/app_access_token"

    data = {
        "app_id": "MjQ3MTM1NjY1MjE0",
        "app_secret": "jjdvSD9H0HYuRAK9RfXFPrLAr70oZN9N"
    }

    response = requests.post(url, json=data)
    response_data = response.json()
    token = response_data.get("app_access_token")
    headers = {
        'Authorization': 'Bearer ' + token,
        'Content-Type': 'application/json'
    }
    return headers


def send_service_notice(headers, text, eid, content):
    headers = dict(headers)
    data = {
        "tag": "interactive_message",
        "employee_codes": ['%s' % (eid)],
        "interactive_message": {
            "default": {
                "elements": [{
                    "element_type": "title",
                    "title": {
                        "text": text
                    }
                },
                    {
                        "element_type": "description",
                        "description": {
                            "text": content
                        }
                    },
                    {
                        "element_type": "button",
                        "button": {
                            "button_type": "callback",
                            "text": "Approve",
                            "value": "approve"
                        }
                    },
                    {
                        "element_type": "button",
                        "button": {
                            "button_type": "callback",
                            "text": "Reject",
                            "value": "reject"
                        }
                    }
                ]
            }
        }
    }

    # 发送POST请求
    print(headers)
    response = requests.post('https://openapi.seatalk.io/messaging/v2/service_notice/send_message', headers=headers,
                             json=data)
    print(response.json())
    if response.status_code == 200:
        card_send_id = response.json()['delivery'][0]['message_id']


        print('消息发送成功')
    else:
        print(f'消息发送失败，状态码为{response.status_code}')

    return card_send_id


def send_msg_to_subscriber(eid, headers, content):
    headers = dict(headers)
    message = {
        #'group_id':"MzEyNzMxMjI2Mjg2",
        'employee_code': eid,
        'message':
            {
                'tag': 'text',
                'text': {
                    'content': content
                }
            }
    }

    print(headers)
    print(content)

    # 发送POST请求
    response = requests.post('https://openapi.seatalk.io/messaging/v2/single_chat', headers=headers, json=message)
    #response_group = requests.post('https://openapi.seatalk.io/messaging/v2/group_chat', headers=headers, json=message)

    # 检查响应状态码
    if response.status_code == 200:
        print('消息发送成功')
    else:
        print(f'消息发送失败，状态码为{response.status_code}')


#SEND IMAGE  TO GROUP

def send_image_to_group(gid,headers,filename):
    headers = dict(headers)
    with open('/root/webhook/image/{}'.format(filename), 'rb') as img_file:
    # 读取图片内
        img_content = img_file.read()

    # 进行Base64编码
        encoded_img = base64.b64encode(img_content).decode("utf-8")
        message = {
            "group_id":gid,
            "message":
                {
                    "tag": 'image',
                    "image": {
                        "content":'{}'.format(encoded_img)
                    }
                }
        }

        print(headers)
        print(encoded_img)

    # 发送POST请求
    #response = requests.post('https://openapi.seatalk.io/messaging/v2/single_chat', headers=headers, json=message)
    response_group = requests.post('https://openapi.seatalk.io/messaging/v2/group_chat', headers=headers, json=message)

    # 检查响应状态码
    if response_group.status_code == 200:
        print(response_group.text)
        print('消息发送成功')
    else:
        print(f'消息发送失败，状态码为{response_group.status_code}')

def send_msg_to_group(gid,headers, content):
    headers = dict(headers)
    message = {
        "group_id":gid,
        #'employee_code': eid,
        "message":
            {
                "tag": 'text',
                "text": {
                    "content": content
                }
            }
    }

    print(headers)
    print(content)

    # 发送POST请求
    #response = requests.post('https://openapi.seatalk.io/messaging/v2/single_chat', headers=headers, json=message)
    response_group = requests.post('https://openapi.seatalk.io/messaging/v2/group_chat', headers=headers, json=message)

    # 检查响应状态码
    if response_group.status_code == 200:
        print(response_group.text)
        print('消息发送成功')
    else:
        print(f'消息发送失败，状态码为{response_group.status_code}')

@app.route("/bot-callback", methods=["POST"])
def bot_callback_handler():
    global headers,card_send_id,info_dict

    body: bytes = request.get_data()
    signature: str = request.headers.get("signature")
    # 1. validate the signature
    if not is_valid_signature(SIGNING_SECRET, body, signature):
        print("Invalid signature!")
        return ""
    # 2. handle events
    data: Dict[str, Any] = json.loads(body)
    event_type: str = data.get("event_type", "")
    print(data)
    if event_type == MESSAGE_FROM_BOT_SUBSCRIBER:
        headers = get_accesstoken_generate_header()
        eid = data["event"]["employee_code"]
        context_data = data['event']['message']['text']['content']
        content = qianwen.call_with_stream(context_data)
        send_msg_to_subscriber(eid, headers, content)
    elif event_type == NEW_MENTIONED_MESSAGE_FROM_GROUP_CHAT:
        eid = data["event"]["message"]["sender"]["employee_code"]
        #gid = "MzEyNzMxMjI2Mjg2"
        #gid = "MjQ3MTM1NjY1MjE0"
        gid = "OTE5NTYxNTgxOTM1"
        context_data = data['event']['message']['text']['plain_text']
        context_data = context_data.replace("@codm_bot", "")
        # 获取 'plain_text' 值
        context_value = data['event']['message']['text']['plain_text']
        # 去除 '@codm_bot '
        cleaned_content = context_value.replace('@codm_bot ', '')
        # 更新 'content' 键的值
        data['event']['message']['text']['content'] = cleaned_content
        # 删除 'plain_text' 键
        del data['event']['message']['text']['plain_text']

        headers = get_accesstoken_generate_header()
        if "dl.codm.cdn.garenanow.com" in context_data or "cdn-1302064167.file.myqcloud.com" in context_data:
            #urls = context_data.split('\n')
            urls = [url.replace('@codm_fco_bot ', '').strip()  for url in context_data.split('\n')]
            print(urls)
            cdn_url = json.dumps({"urls": urls})
            batchid, response0 = cdn_prefetch.run1(cdn_url)
            data = response0.json()
            if response0.status_code == 200:
                totalurls = data["batch"]["totalUrls"]
                completedurls = data["batch"]["completedUrls"]
                pendingurls = len(data["batch"]["pendingUrls"])
                content = "返回码{},已推送cdn链接如下，正在进行CVS预热，请稍后....(请勿重复推送链接)\n{}\ntotal_urls：{}\n已完成预热:{}\n等待预热:{}\n请粘贴以下命令进行查询：\ncdn预热查询 {}".format(
                    response0.status_code, '\n'.join(urls), totalurls, completedurls, pendingurls, batchid)
                #for cdn_eid in ["82216","82043","7937","4841"]:
                #for cdn_eid in ["82216","82043"]:
              #      send_msg_to_subscriber(cdn_eid, headers, content)
                send_msg_to_group(gid, headers, content)
            elif response0.status_code != 200:
                content = "返回码{},预热失败，请联系GTO检查\n{}".format(response0.status_code, data)
             #   send_msg_to_subscriber(eid, headers, content)
                send_msg_to_group(gid, headers, content)
        elif "cdn预热查询" in context_data:
            batchid = context_data.split(' ')[-1]
            response = cdn_prefetch.run2(batchid)
            data = response.json()
            totalurls = data["batch"]["totalUrls"]
            completedurls = data["batch"]["completedUrls"]
            pendingurls = len(data["batch"]["pendingUrls"])
            if totalurls == completedurls:
                content = "返回码{},预热完成\ntotal_url:{}\n已完成预热:{}\n等待预热:{}\n".format(response.status_code, totalurls,
                                                                                 completedurls, pendingurls)
            else:
                content = "返回码{},预热还在进行中\ntotal_url:{}\n已完成预热:{}\n等待预热:{}\n".format(response.status_code, totalurls,
                                                                                  completedurls, pendingurls)
            #send_msg_to_subscriber(eid, headers, content)
            send_msg_to_group(gid, headers, content)

        elif "发布环境" in context_data:
            bot_msg, card_msg, text, info_dict = bk_task.run_1(data)
            if card_msg:
                card_send_id = send_service_notice(headers, text, eid, card_msg)
            elif bot_msg:
             #   send_msg_to_subscriber(eid, headers, bot_msg)
                send_msg_to_group(gid, headers, content)
        elif "第一台已确认可以继续执行" in context_data:
            content = bk_task.confirm_first(data)
            #send_msg_to_subscriber(eid,headers,content)
            send_msg_to_group(gid, headers, content)
        #FCOVN RESTART
        elif "FCOVN NEXTLIVE" in context_data:
            context = fcovn_restart.exec_job()
            send_msg_to_group(gid,headers,context)
            #pass
        elif "功能查询" in context_data:
            context = fcovn_restart.exec_guide()
            send_msg_to_group(gid,headers,context)
        elif "codmimage" in context_data:
            #filename = send_image_to_group(codm.png)
            send_image_to_group(gid,headers,"codm.png")
        elif "fcoimage" in context_data:
            send_image_to_group(gid,headers,"fco.jpg") 
        else:
            context = qianwen.call_with_stream(context_data)
            send_msg_to_group(gid,headers,context)

    elif event_type == INTERACTIVE_MESSAGE_CLICK:
        eid = data["event"]["employee_code"]
        gid = "OTE5NTYxNTgxOTM1"
        choice = data['event']['value']
        card_response_id = data['event']['message_id']
        if choice == "approve" and card_response_id == card_send_id:
            task_id, task_url, content = bk_task.run_2(info_dict)
            #send_msg_to_subscriber(eid, headers, content)
            send_msg_to_group(gid, headers, content)
        if choice == "reject" and card_response_id == card_send_id:
            content = "你已拒绝创建该任务，请重新张贴发布单"
            #send_msg_to_subscriber(eid, headers, content)
            send_msg_to_group(gid, headers, content)
        else:
            pass

    else:
        pass
        #context = fcovn_restart.exec_illegal()
        #send_msg_to_group(gid,headers,context)
    return ""


if __name__ == "__main__":
    app.run(host=HOST, port=PORT, debug=True)
