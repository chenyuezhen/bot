import hashlib
import json
from typing import Dict, Any

from flask import Flask, request
import requests
import datetime
import time

# settings
SIGNING_SECRET = b"W1mdtlLBg3Ox38eut-3uAaiX9dcTZcVd"
HOST = "0.0.0.0"
PORT = 19091

# event list
# ref: https://open.seatalk.io/docs/list-of-events
EVENT_VERIFICATION = "event_verification"
NEW_BOT_SUBSCRIBER = "new_bot_subscriber"
MESSAGE_FROM_BOT_SUBSCRIBER = "message_from_bot_subscriber"
INTERACTIVE_MESSAGE_CLICK = "interactive_message_click"

app = Flask(__name__)


def is_valid_signature(signing_secret: bytes, body: bytes, signature: str) -> bool:
    # ref: https://open.seatalk.io/docs/server-apis-event-callback
    return hashlib.sha256(body + signing_secret).hexdigest() == signature


def get_access_token():
    url = "https://openapi.seatalk.io/auth/app_access_token"

    data = {
        "app_id": "MjQ3MTM1NjY1MjE0",
        "app_secret": "jjdvSD9H0HYuRAK9RfXFPrLAr70oZN9N"
    }

    response = requests.post(url, json=data)
    response_data = response.json()
    token = response_data.get("app_access_token")
    return token


def send_msg_to_subscriber(eid, info, token):
    # 构造请求头部信息
    # 构造请求体信息
    headers = {
        'Authorization': 'Bearer ' + token,
        'Content-Type': 'application/json'
    }
    if len(info) == 6:
        response_content = f"环境：{info['env']}\nfilename: {info['file_name'].strip()}\n进程：{info['process_name']}\ncmd：{info['cmd']}\nmd5：{info['md5']}\ngenshell：{info['genshell']}"

    else:
        response_content = "抱歉你的输入无法识别，目前仅支持粘贴发布单解析"

    message = {
        'employee_code': eid,
        'message': {
            'tag': 'text',
            'text': {
                'content': response_content
            }
        }
    }

    # 发送POST请求
    response = requests.post('https://openapi.seatalk.io/messaging/v2/single_chat', headers=headers, json=message)

    # 检查响应状态码
    if response.status_code == 200:
        print('消息发送成功')
    else:
        print(f'消息发送失败，状态码为{response.status_code}')


def create_sops_task(taskname, template_id, file, process, cmd):
    # 设置请求地址和参数
    url = "http://paas.codmbk.garena.com:80/api/c/compapi/v2/sops/create_task/"
    params = {
        "bk_app_code": "bk_sops",
        "bk_app_secret": "ff9ed1a0-effc-4722-be09-0e3d8fe20d84",
        "bk_username": "wen.zeng",
        "name": taskname,
        "bk_biz_id": "3",
        "template_id": template_id,
        "template_source": "business",
        "constants": {
            "${file}": file,
            "${process}": process,
            "${cmd}": cmd
        },
        "simplify_vars": ["${file}", "${process}", "${cmd}"],
        "exclude_task_nodes_id": [11],
        "scope": "cmdb_biz",
    }

    # 发送请求
    response = requests.post(url, data=json.dumps(params))

    # 解析响应
    result = json.loads(response.text)
    if result["result"]:
        task_id = result["data"]["task_id"]
        task_result = "成功创建任务，任务ID为：{}".format(task_id)
        print(task_result)
    else:
        task_result = "创建任务失败，错误信息为：{}".format(result["message"])
        print(task_result)
    return task_result



def extract_info(data: Dict[str, Any]) -> Dict[str, Any]:
    message = data["event"]["message"]["text"]["content"]
    employee_code = "e_{}".format(data["event"]["employee_code"])
    lines = message.split("\n")
    info = {}
    for line in lines:
        if "发布环境" in line:
            info["env"] = line.split("：")[1]
        elif "文件名称" in line:
            info["file_name"] = line.split("：")[1]
        elif "进程名" in line:
            info["process_name"] = line.split("：")[1]
        elif "reload" in line:
            info["cmd"] = "reload"
        elif "restart" in line:
            info["cmd"] = "restart"
        elif "构建检查" in line:
            info["md5"] = line.split(" ")[-1]
        elif "genshell" in line:
            info['genshell'] = "yes"
        elif "genshell" not in line:
            info['genshell'] = "no"
        else:
            pass
    return info


@app.route("/bot-callback", methods=["POST"])
def bot_callback_handler():
    body: bytes = request.get_data()
    signature: str = request.headers.get("signature")
    # 1. validate the signature
    if not is_valid_signature(SIGNING_SECRET, body, signature):
        print("Invalid signature!")
        return ""
    # 2. handle events
    data: Dict[str, Any] = json.loads(body)
    event_type: str = data.get("event_type", "")
    if event_type == EVENT_VERIFICATION:
        return data.get("event")
    elif event_type == NEW_BOT_SUBSCRIBER:
        # fill with your own code
        pass
    elif event_type == MESSAGE_FROM_BOT_SUBSCRIBER:
        eid_list = ['82216']
        access_token = get_access_token()
        print(access_token)
        info = extract_info(data)
        print(info)
        for eid in eid_list:
            send_msg_to_subscriber(eid, info, access_token)

    elif event_type == INTERACTIVE_MESSAGE_CLICK:
        # handle interactive message click event
        pass
    else:
        pass
    return ""


if __name__ == "__main__":
    app.run(host=HOST, port=PORT, debug=True)
