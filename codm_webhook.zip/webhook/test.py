#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import cdn_prefetch

url = '{"urls": ["https://dl.codm.cdn.garenanow.com/codm/test0524/0524test.txt", "https://dl.codm.cdn.garenanow.com/codm/test0524/response.json"]}'
batchid, response = cdn_prefetch.run(url)

print(batchid,response.json())
