from flask import Flask, request

app = Flask(__name__)

@app.route('/', methods=["POST"])
def index():
    req = request.json
    print(req)
    return 'success!'

if __name__ == '__main__':
    HOST = "0.0.0.0"
    PORT = 19091
    app.run(host=HOST,port=PORT,debug=True)
