import requests
import hashlib
import hmac
import random
import time


# 生成请求头
def generate_headers(access_key_id, access_key_secret, uri, request_body, request_mothod):
    request_timestamp = time.strftime("%Y%m%dT%H%M%SZ", time.localtime(time.time() + time.timezone))
    nonce = random.randint(10000, 99999)
    signing_string = "%s\n%s\n%s\n%s\n%s\n%s" % (
    request_mothod.upper(), uri, request_timestamp, nonce, access_key_id, request_body)

    signature = hmac.new(access_key_secret.encode('utf-8'), signing_string.encode('utf-8'),
                         hashlib.sha256).hexdigest()

    authorization_val = f"HMAC-SHA256 {access_key_id}:{signature}"
    headers = dict()
    headers['Authorization'] = authorization_val
    headers['Content-Type'] = "application/json; charset=utf-8"
    headers['X-SFD-Date'] = request_timestamp
    headers['X-SFD-Nonce'] = str(nonce)
    return headers


# 发送预热请求
def send_prefetch_request(access_key_id, access_key_secret, cdn_request_body):
    api_url = 'https://cdn-api.swiftfederation.com/v2.0/services/42452/prefetches'
    uri = '/v2.0/services/42452/prefetches'
    request_mothod = 'POST'
    headers = generate_headers(access_key_id, access_key_secret, uri, cdn_request_body, request_mothod)
    response = requests.post(api_url, headers=headers, data=cdn_request_body)
    data = response.json()
    batchid = data["batchId"]
    return batchid


##检查预热
def check_prefetch(access_key_id, access_key_secret,batchid):
    api = 'https://cdn-api.swiftfederation.com/v2.0/services/42452/prefetches/{}'.format(batchid)
    uri = '/v2.0/services/42452/prefetches/{}'.format(batchid)
    request_mothod = 'GET'
    request_body = ''
    headers = generate_headers(access_key_id, access_key_secret, uri, request_body, request_mothod)
    response = requests.get(api, headers=headers, data=request_body)
    return response


def run1(cdn_url):
    access_key_id = "ql5n540D8CJ07j6d"
    access_key_secret = "83B21658s08W56S69791L0r4GxbW2oxy"
    batchid = send_prefetch_request(access_key_id, access_key_secret, cdn_url)
    response = check_prefetch(access_key_id, access_key_secret, batchid)
    return batchid,response


def run2(batchid):
    access_key_id = "ql5n540D8CJ07j6d"
    access_key_secret = "83B21658s08W56S69791L0r4GxbW2oxy"
    response = check_prefetch(access_key_id, access_key_secret, batchid)
    return response    



if __name__ == "__main__":
    access_key_id = "ql5n540D8CJ07j6d"
    access_key_secret = "83B21658s08W56S69791L0r4GxbW2oxy"
    cdn_url = '{"urls":["https://dl.codm.cdn.garenanow.com/codm/test0524/response.json"]}'
    batchid,r0 = run1(cdn_url)

    print(batchid,r0.json())
    completedurls,totalurls,pendingurls = run2(batchid)
    print(completedurls,totalurls,pendingurls)

