# -*- coding: utf-8 -*-

import json
from typing import Dict, Any
import requests
import datetime

import re


def send_card_notice_msg(info):
    text = "刷包信息如下，请确认"
    content = f"版本：{info['version']}\n环境：{info['env']}\nfilename: {info['file_name'].strip()}\n进程：{info['process_name']}\ncmd：{info['cmd']}\nmd5：{info['md5']}\ngenshell：{info['genshell']}"
    return text, content


def send_bot_msg(info, task_result=None):
    content = f"版本：{info['version']}\n环境：{info['env']}\nfilename: {info['file_name'].strip()}\n进程：{info['process_name']}\ncmd：{info['cmd']}\nmd5：{info['md5']}\ngenshell：{info['genshell']}\n\n{task_result}"
    return content


def extract_info(data: Dict[str, Any]) -> Dict[str, Any]:
    message = data["event"]["message"]["text"]["content"]
    lines = message.split("\n")
    info = {}
    info.setdefault('genshell', 'no')
    for line in lines:
        match_single = re.search(r'(\d+\.\d+)\]现网', line)
        match_multiple = re.search(r'(\d+\.\d+)\+(\d+\.\d+)\]现网', line)
        if match_single:
            info['version'] = match_single.group(1)
        elif match_multiple:
            info['version'] = match_multiple.group(1)
        if "发布环境" in line:
            info["env"] = line.split("：")[1]
        elif "文件名称" in line:
            info["file_name"] = line.split("：")[1]
        elif "进程名" in line:
            info["process_name"] = line.split("：")[1].replace(",", ' ')
        elif "操作方式" in line:
            if "genshell" in line:
                info['genshell'] = "yes"
            if "reload" in line:
                info["cmd"] = "reload"
            elif "restart" in line:
                info["cmd"] = "restart"
        elif "构建检查" in line:
            info["md5"] = line.split(" ")[-1]
        else:
            pass

    print(info)
    return info


def create_sops_task(info_dict):
    version = info_dict["version"]
    env = info_dict["env"]
    file = info_dict["file_name"]
    process = info_dict["process_name"]
    cmd = info_dict["cmd"]
    md5 = info_dict["md5"]
    genshell = info_dict["genshell"]

    # 判断发布单环境确定参数
    version = info_dict["version"]
    env = info_dict["env"]
    file = info_dict["file_name"]
    process = info_dict["process_name"]
    cmd = info_dict["cmd"]
    md5 = info_dict["md5"]
    genshell = info_dict["genshell"]

    # 判断发布单环境确定参数
    if version == "21.0":
        if "正式" in env or "live" in env:
            template_id = "46"
            template_name = "【运维用正式服wwl21】刷配置"
            constants = {
                "${file}": file,
                "${process}": process,
                "${cmd}": cmd,
                "${md5code}": md5,
                "${Is_genshell}": genshell
            }
            simplify_vars = ["${file}", "${process}", "${cmd}", "${md5code}", "${Is_genshell}"]

        elif "预发布" in env or "nonstop" in env:
            template_id = "45"
            template_name = "【运维用预发布wwl21】刷配置"
            constants = {
                "${file}": file,
                "${process}": process,
                "${cmd}": cmd,
                "${genshell}": genshell
            }
            simplify_vars = ["${file}", "${process}", "${cmd}"]
    elif version == "22.0":
        if "正式" in env or "live" in env:
            template_id = "43"
            template_name = "【运维用正式服wwl22】刷配置"
            constants = {
                "${file}": file,
                "${process}": process,
                "${cmd}": cmd,
                "${md5code}": md5,
                "${Is_genshell}": genshell
            }
            simplify_vars = ["${file}", "${process}", "${cmd}", "${md5code}", "${Is_genshell}"]

        elif "预发布" in env or "nonstop" in env:
            template_id = "13"
            template_name = "【运维用预发布wwl22】刷配置"
            constants = {
                "${file}": file,
                "${process}": process,
                "${cmd}": cmd,
                "${genshell}": genshell
            }
            simplify_vars = ["${file}", "${process}", "${cmd}"]

    current_time = datetime.datetime.now()
    current_time_str = current_time.strftime("%Y-%m-%d_%H-%M-%S")
    taskname = "{}_{}_bybot".format(template_name, current_time_str)

    # 设置请求地址和参数
    url = "http://paas.codmbk.garena.com:80/api/c/compapi/v2/sops/create_and_start_task/"
    #url = "http://paas.codmbk.garena.com:80/api/c/compapi/v2/sops/create_task/"
    params = {
        "bk_app_code": "bk_sops",
        "bk_app_secret": "ff9ed1a0-effc-4722-be09-0e3d8fe20d84",
        "bk_username": "wen.zeng",
        "name": taskname,
        "bk_biz_id": "3",
        "template_id": template_id,
        "template_source": "business",
        "constants": constants,
        "simplify_vars": simplify_vars,
        "scope": "cmdb_biz"
    }

    # 发送请求
    response = requests.post(url, data=json.dumps(params))

    # 解析响应
    result = json.loads(response.text)
    if result["result"]:
        task_url = result["data"]["task_url"]
        task_id = result["data"]["task_id"]
        content = "版本:{}\n环境:{}\nfilename:{}\n进程:{}\ncmd:{}\nmd5:{}\ngeshell:{}".format(
            version,env,file,process,cmd,md5,genshell
        )
        task_result = "{}\n\n成功创建任务，任务ID为：{}\n任务链接:{}\n\n如正式环境需要确认第一台，请粘贴以下命令\n任务ID:{},第一台已确认可以继续执行".format(content,task_id,task_url,task_id)
        print(task_result)
    else:
        task_result = "创建任务失败，错误信息为：{}".format(result["message"])
        print(task_result)
    return task_id,task_url,task_result


def confirm_first(data):
    task_id = data['event']['message']['text']['content'].split(',')[0].split(':')[1]
    ## 获取暂停的节点ID
    get_nodeid_url = "http://paas.codmbk.garena.com:80/api/c/compapi/v2/sops/get_tasks_status/"
    data1 = {
        "bk_app_code": "bk_sops",
        "bk_app_secret": "ff9ed1a0-effc-4722-be09-0e3d8fe20d84",
        "bk_username": "wen.zeng",
        "bk_biz_id": "3",
        "task_id_list": ['{}'.format(task_id)],
        "scope": "cmdb_biz",
        "include_children_status": True
        }
    response = requests.post(get_nodeid_url,data=json.dumps(data1))
    response_data = response.json()
    for item in response_data["data"]:
        for child in item["status"]["children"].values():
            # 检查name是否等于"暂停"
            if child.get("name") == "suspend":
                node_id = child['id']

    ###拿到获取的nodeid进行操作
    oparate_url = "http://paas.codmbk.garena.com:80/api/c/compapi/v2/sops/operate_node/"
    params ={
        "bk_app_code": "bk_sops",
        "bk_app_secret": "ff9ed1a0-effc-4722-be09-0e3d8fe20d84",
        "bk_biz_id": "3",
        "bk_username": "wen.zeng",
        "task_id": "{}".format(task_id),
        "node_id": node_id,
        "action": "callback",
        "scope": "cmdb_biz"
    }

 # 发送请求
    response = requests.post(oparate_url, data=json.dumps(params))
    result = response.json()
    print(result)
    if result["result"]:
        content = "taskid：{} 第一台已确认继续执行，节点ID{}".format(task_id,node_id)
    else:
        content = "第一台确认执行失败，请检查"
    print(content)
    return content



def run_1(data):
    bot_msg, card_msg, text = None, None, None
    info_dict = extract_info(data)
    required_keys = ['genshell', 'version', 'env', 'file_name', 'process_name', 'cmd', 'md5']

    if len(info_dict) == len(required_keys):
        missing_keys = []
        for key in required_keys:
            if key not in info_dict or info_dict[key].strip() == "":
                missing_keys.append(key)

        if len(missing_keys) > 0:
            bot_msg = "发布单格式存在问题，缺少必要的提取信息，缺少值的键是: {}".format(", ".join(missing_keys))
        else:
            text, card_msg = send_card_notice_msg(info_dict)
    else:
        bot_msg = '抱歉，你的发布单格式不符，请重新输入'

    return bot_msg, card_msg, text,info_dict

def run_2(info_dict):
    task_id,task_url,task_result = create_sops_task(info_dict)
    return task_id,task_url,task_result






if __name__ == "__main__":
    data = {'event_id': 'db186b4d-7e0c-43d4-946b-a1fb101c7277', 'event_type': 'message_from_bot_subscriber',
            'timestamp': 1685696101, 'app_id': 'MjQ3MTM1NjY1MjE0', 'event': {'employee_code': '82216',
                                                                             'message': {'tag': 'text', 'text': {
                                                                               'content': '【CODM服务器】- 【[五线15.0+21.0]现网发布(局内专用)】#194 garena_7340\nreload进程\n发布环境：预发布\n变更事项：【WWL21.1+CN15.1】【服务器】.1周热更2值班\n文件名称：codm_garena_live_20230601_1958_902201042d7cdb63ce4cd94bde60b5cf_7340.tgz\nMD5：902201042d7cdb63ce4cd94bde60b5cf\n进程名：dsagent1\n操作方式：1 genshell 2 reload dsagent1,dsagent2\n————————————————\n以下为补充说明：（开发和运维同学看）\n文件大小：288M     \n打包文件：codm/dsagent1/etc/dsa_version_out.xml         codm/dsagent2/etc/dsa_version_out.xml           codm/es_1.0.21.1/patch3\n构建检查：codm/build_version b1554b682bf16522170e9019307a8188\n构建人：johnychen\n构建时间：2023-06-01 19:43:10\n构建SVN:  /branches/CODM/20230512_svn1128083_WWL21.1_15.1/ -r1138116 \n协议MD5: PB_XML_MD5:7632ec41107f2624263d9263e999d0eb_DS_XML_MD5:ec3e28623e96e727e02eed8ec6d59034\n发布单：\n @曾文 帮忙发下预发布'}}}}
    
    bot_msg, card_msg, text,info_dict = run_1(data)
    print(bot_msg, card_msg, text,info_dict)
    task_id, task_url, task_result = create_sops_task(info_dict)
    print(task_id, task_url, task_result)


