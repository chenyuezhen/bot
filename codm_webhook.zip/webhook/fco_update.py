#!/usr/local/bin/python3.7
# -*- coding: utf-8 -*-



import requests
import sys

def get_token():
    url = "https://queenbee.gre.garenanow.com/api/ccu/login"  # Replace with the actual API endpoint URL
    headers = {
        "Content-Type": "application/json",
    }

    data = {
        "username": "yuezhen.chen@garena.cn",
         "password": "J7eKDHCY6PcdMxG5"

    }

    response = requests.post(url, headers=headers, json=data)

    if response.status_code == 200:  # 假设响应状态码为200表示成功
        response_data = response.json()  # 将响应内容解析为JSON

        # 从响应数据中提取token值
        token = response_data['data']['token']

        print("Token:", token)
    else:
        print("请求失败，状态码:", response.status_code)
    return token


def vn_exec_job(token,version):

    job_headers = {
        "Content-Type": "application/json",
        "Token":token,
        "currentuser": 'yuezhen.chen@garena.cn'
    }

    jobexec_url = "https://queenbee.gre.garenanow.com/api/v2/task/app/8/654c54c68d16316286dd514a/run"

    job_data = {
        "id": "654c54c68d16316286dd514a",
        "variables": [ {
            "name": "chart_version",
            "type": 7,
            "defaultValue": version
        }
        ]
    }

    print(job_data)
    job_response = requests.post(jobexec_url, headers=job_headers, json=job_data)
    print(job_response.json())
    return job_response

def th_exec_job(token,version):

    job_headers = {
        "Content-Type": "application/json",
        "Token":token,
        "currentuser": 'yuezhen.chen@garena.cn'
    }

    jobexec_url = "https://queenbee.gre.garenanow.com/api/v2/task/app/8/654c52268d16316286dd4032/run"

    job_data = {
        "id": "654c52268d16316286dd4032",
        "variables": [ {
            "name": "chart_version",
            "type": 7,
            "defaultValue": version
        }
        ]
    }

    print(job_data)
    job_response = requests.post(jobexec_url, headers=job_headers, json=job_data)
    print(job_response.json())
    return job_response


if __name__ == "__main__":
    if len(sys.argv) > 1:
        version = sys.argv[1]
    else:
        print("请输入一个正确的chartversion")
#    vn_exec_job(get_token(),version)
