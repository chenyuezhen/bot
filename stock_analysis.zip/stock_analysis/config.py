import os

class Config:
    # 获取当前文件所在目录的绝对路径
    basedir = os.path.abspath(os.path.dirname(__file__))
    
    # SQLite数据库配置
    SQLALCHEMY_DATABASE_URI = 'sqlite:///' + os.path.join(basedir, 'app.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # Flask配置
    SECRET_KEY = 'your-secret-key-here'  # 请更改为随机字符串
