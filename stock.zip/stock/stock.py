import pywencai
import pandas as pd
import datetime
import smtplib
import email.utils
import os
from collections import Counter
import logging
from wordcloud import WordCloud
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from email import encoders
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.base import MIMEBase

# 设置显示的最大行数和列数
pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
# 获取数据
result = pywencai.get(query='今日涨停，非ST，非北京交易所，及其所属行业板块及涨停原因分析', sort_order='asc', loop=True,perpage=100)
# 遍历字典并输出每个键值对
# for key, value in result.items():
#     print(f'key是{key}: value是{value}')
df = pd.DataFrame(result)

# 获取当前日期
current_date = datetime.datetime.now().strftime('%Y%m%d')
# 构建目录路径
parent_directory = f'stock_{current_date}'
# 创建目录
try:
    os.makedirs(parent_directory)
    print(f"目录 '{parent_directory}' 创建成功！")
except OSError as e:
    if e.errno == os.errno.EEXIST:
        print(f"目录 '{parent_directory}' 已经存在，无需创建。")
    else:
        # 如果是其他错误，将异常重新抛出
        raise
# 构建文件名
file_name = f"stock_{current_date}/{current_date}.csv"
file_name_new = f"stock_{current_date}/{current_date}_new.xlsx"
log_file_name = f"stock_{current_date}/{current_date}_result.log"
# 将 DataFrame 写入 CSV 文件，并指定编码为 'utf-8'
df.to_csv(file_name, index=False, encoding='utf-8')
#read_csv 加载csv文件
df = pd.read_csv(file_name)
#词云图目录
font_path = "/data/test/stock/chinese.simhei.ttf"

#生成所需精简内容# 选择列名为 'column1' 和 'column2' 的内容
df_sorted = df.sort_values(by='所属同花顺行业')
selected_columns = df_sorted[['股票代码', '股票简称','所属同花顺行业','涨停原因类别[{}]'.format(current_date),'几天几板[{}]'.format(current_date)]]
# selected_columns = df_sorted[['股票代码', '股票简称','所属同花顺行业','涨停原因类别[20231124]','几天几板[20231124]']]
# 将选定的两列保存到新文件
selected_columns.to_excel(file_name_new, index=False,sheet_name='{}_涨停'.format(current_date))

#email part
message = MIMEMultipart()
message['To'] = email.utils.formataddr(('Sherry', 'yuezhen.chen@garena.com'))
message['From'] = email.utils.formataddr(('Reason', '347202084@qq.com'))
message['Subject'] = '{} A Stock Market Summary'.format(current_date)
# image_paths = ["path_to_image1.jpg", "path_to_image2.jpg", "path_to_image3.jpg"]

def gen_wordcloud(module):
    industry_values = df[module].values
    wordcloud_content = str(industry_values)
    # 生成词云
    wordcloud = WordCloud(width=800, height=400, background_color='white', font_path=font_path).generate(wordcloud_content)
    # 保存词云图像到本地目录
    return wordcloud.to_file('stock_{}/{}_{}.png'.format(current_date,current_date,module))

def gen_dailylist(module):
    industry_values = df[module].values
    if "所属同花顺行业" in module:
        df['sub_{}'.format(module)] = df[module].str.split('-')
    elif "涨停原因类别" in module:
        df['sub_{}'.format(module)] = df[module].str.split('+')
    else:
        df['sub_{}'.format(module)] = df[module].str.split(';')
    all_subcategories = [subcategory for sublist in df['sub_{}'.format(module)] for subcategory in sublist]
    subcategory_counts = pd.Series(all_subcategories).value_counts()
    sorted_subcategory_counts = subcategory_counts.sort_values(ascending=False)
    subcategory_dict = sorted_subcategory_counts.to_dict()
    return (subcategory_dict)

gen_wordcloud('所属同花顺行业')
gen_wordcloud('涨停原因类别[{}]'.format(current_date))
gen_wordcloud('所属概念')

print(gen_dailylist('所属同花顺行业'))
print(gen_dailylist('涨停原因类别[{}]'.format(current_date)))
print(gen_dailylist('所属概念'))


def content_id(images):
    # 需要发送的图片
    img_file = open(images, 'rb')
    img_data = img_file.read()
    img_file.close()
    img = MIMEImage(img_data)
    img_id = images.split("/")[-1].split(".")[0]  # 提取文件名作为Content-ID
    img.add_header('Content-ID', f"<{img_id}>")  # 给一个content Id供后面html内容引用
    message.attach(img)
    return img_id


# 添加词云图像
img_ids = [
        content_id("/data/test/stock/stock_{0}/{1}_所属同花顺行业.png".format(current_date,current_date)),
        content_id("/data/test/stock/stock_{0}/{1}_涨停原因类别[{2}].png".format(current_date,current_date,current_date)),
        content_id("/data/test/stock/stock_{0}/{1}_所属概念.png".format(current_date,current_date))
    ]

def send_email(subject, mail_content, attachment_paths=None):
    # 创建邮件对象
    message = MIMEMultipart()
    message['To'] = email.utils.formataddr(('Sherry', 'yuezhen.chen@garena.com'))
    message['From'] = email.utils.formataddr(('Reason', '347202084@qq.com'))
    message['Subject'] = subject

    # 添加文本内容
    message.attach(MIMEText(mail_content, 'html', 'utf-8'))

    # # 添加图片
    # if image_paths:
    #     for image_path in image_paths:
    #         with open(image_path, 'rb') as img_file:
    #             img_data = img_file.read()
    #             img = MIMEImage(img_data)
    #             content_id = str(uuid.uuid4())  # 使用UUID作为Content-ID
    #             img.add_header('Content-ID', f'<{content_id}>')
    #             message.attach(img)
    # 添加词云图像
    img_ids = [
        content_id("/data/test/stock/{}_所属同花顺行业.png".format(
            current_date)),
        content_id(
            "/data/test/stock/{0}_涨停原因类别[{0}].png".format(
                current_date, current_date)),
        content_id(
            "/data/test/stock/{}_所属概念.png".format(current_date))
    ]
    # 添加附件
    if attachment_paths:
        for attachment_path in attachment_paths:
            with open(attachment_path, 'rb') as attachment_file:
                attachment_payload = MIMEBase("application", "octet-stream")
                attachment_payload.set_payload(attachment_file.read())
                encoders.encode_base64(attachment_payload)
                attachment_payload.add_header('Content-Disposition', f'attachment; filename="{attachment_path}"')
                message.attach(attachment_payload)

    # 连接SMTP服务器并发送邮件
    smtp_obj = smtplib.SMTP_SSL('smtp.qq.com', 465)
    smtp_obj.login('347202084@qq.com', 'esldqwmvjrswbjai')
    smtp_obj.set_debuglevel(True)
    try:
        smtp_obj.sendmail('347202084@qq.com', ["yuezhen.chen@garena.com"], msg=message.as_string())
    finally:
        smtp_obj.quit()

# 示例用法
subject = '测试邮件'
# #构建邮件body
# mail_content = """
#        <html>
#          <body>
#            <p>{0} 所有涨停个股所属同花顺行业中数据: {1}  </p>
#            <p>所属同花顺词云图如下:</p>
#            <img src="cid:{4}">
#
#            <p>{0} 所有涨停个股涨停原因类别: {2} </p>
#            <p>涨停个股涨停原因类别词云图如下:</p>
#            <img src="cid:{5}">
#
#            <p>{0} 所有涨停个股所属板块数据: {3} </p>
#            <p>所属板块词云图如下:</p>
#            <img src="cid:{6}">
#
#          </body>
#        </html>
#    """.format(current_date, gen_dailylist("所属同花顺行业"), gen_dailylist("涨停原因类别[{}]".format(current_date)),
#               gen_dailylist("所属概念"),content_id("/Users/chenyuezhen/PycharmProjects/pythonProject/github-copilot/personal/{}_所属同花顺行业.png".format(current_date)),
#               content_id("/Users/chenyuezhen/PycharmProjects/pythonProject/github-copilot/personal/{0}_涨停原因类别[{0}].png".format(current_date,current_date)),
#               content_id("/Users/chenyuezhen/PycharmProjects/pythonProject/github-copilot/personal/{}_所属概念.png".format(current_date)))

mail_content = """
       <html>
         <body>
           <p>{0} 所有涨停个股所属同花顺行业中数据: {1}  </p>
           <p>所属同花顺词云图如下:</p>
           <img src="cid:{2}">

           <p>{0} 所有涨停个股涨停原因类别: {3} </p>
           <p>涨停个股涨停原因类别词云图如下:</p>
           <img src="cid:{4}">

           <p>{0} 所有涨停个股所属板块数据: {5} </p>
           <p>所属板块词云图如下:</p>
           <img src="cid:{6}">

         </body>
       </html>
   """.format(current_date, gen_dailylist("所属同花顺行业"), img_ids[0],
              gen_dailylist("涨停原因类别[{}]".format(current_date)), img_ids[1],
              gen_dailylist("所属概念"), img_ids[2])

# image_paths = ["20231115_所属同花顺行业.png","20231115_涨停原因类别[20231115].png","20231115_所属概念.png"]
attachment_paths =["20231115.csv"]

# send_email(subject, mail_content, attachment_paths)

# print(mail_content)
# gen_wordcloud('所属同花顺行业')
# gen_wordcloud('涨停原因类别[{}]'.format(current_date))
# gen_wordcloud('所属概念')

# gen_dailylist('所属同花顺行业')
# gen_dailylist('涨停原因类别[{}]'.format(current_date))
# gen_dailylist('所属概念')



# df['所属同花顺子行业'] = df['所属同花顺行业'].str.split('-')
#
# # 将每个子板块提取出来，并存储在一个列表中
# all_subcategories = [subcategory for sublist in df['所属同花顺子行业'] for subcategory in sublist]
#
# # 使用Pandas的value_counts()函数统计每个子板块的出现次数
# subcategory_counts = pd.Series(all_subcategories).value_counts()
#
# # 将统计结果按照出现次数降序排列
# sorted_subcategory_counts = subcategory_counts.sort_values(ascending=False)
#
# # 将结果转为字典格式
# subcategory_dict = sorted_subcategory_counts.to_dict()
# print(subcategory_dict)
#
# # #读取csv文件
# # df = pd.read_csv(file_name, usecols=[5],header=None)  # 6th column is index 5 in Python
# # print (df.iloc[:,0].values)# ":"表示所有行，",5"表示第6列
#
#
#
#
#
# # # 设置日志记录
# # logging.basicConfig(filename=log_file_name, level=logging.INFO, format='%(message)s')
# #
# # # 选择第6列、第8列和第10列，并输出到日志文件
# # # selected_columns = res.iloc[:, [5, 7]]
# # selected_columns = res.iloc[:, [5]]
# # print(selected_columns)
# # for row in selected_columns.itertuples(index=False):
# #     log_message = '\t'.join(map(str, row))  # 使用制表符分隔列
# #     logging.info(log_message)
# #
# # # 关闭日志记录
# # logging.shutdown()
