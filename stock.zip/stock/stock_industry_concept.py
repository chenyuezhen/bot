import plotly.express as px
import qstock as qs
import pandas as pd
from datetime import datetime
import os

# 获取当前日期
current_date = datetime.now().strftime("%Y%m%d")

# 确保目录存在
os.makedirs(f"/data/test/stock/stock_{current_date}", exist_ok=True)

# 获取行业板块实时涨跌幅数据
industry_data = qs.realtime_data('行业板块')[['名称', '涨幅']]
industry_data['权重'] = abs(industry_data['涨幅'])
industry_data = industry_data[industry_data['涨幅'] != 0]

# 获取概念板块实时涨跌幅数据
concept_data = qs.realtime_data('概念板块')[['名称', '涨幅']]
concept_data['权重'] = abs(concept_data['涨幅'])
concept_data = concept_data[concept_data['涨幅'] != 0]

# 第一个图：行业板块
fig1 = px.treemap(industry_data, path=[px.Constant("行业板块"), '名称'], values='权重', color='涨幅',
                  color_continuous_scale='RdBu', title="行业板块涨跌幅",
                  custom_data=['名称', '涨幅'])
fig1.update_traces(textinfo="label+text+value", texttemplate="%{customdata[0]}<br>%{customdata[1]}%")
fig1.update_layout(margin=dict(t=50, l=25, r=25, b=25), width=750, height=500)
fig1.write_image(f"/data/test/stock/stock_{current_date}/{current_date}_industry.png", scale=3)

# 第二个图：概念板块
fig2 = px.treemap(concept_data, path=[px.Constant("概念板块"), '名称'], values='权重', color='涨幅',
                  color_continuous_scale='RdBu', title="概念板块涨跌幅")
fig2.update_traces(textinfo="label+text+value", texttemplate="%{label}<br>%{value}%")
fig2.update_layout(margin=dict(t=50, l=25, r=25, b=25), width=1800, height=1200)
fig2.write_image(f"/data/test/stock/stock_{current_date}/{current_date}_concept.png", scale=3)

