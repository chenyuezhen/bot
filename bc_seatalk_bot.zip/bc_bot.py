import os
import hashlib
import json
import time
#import bc_release
from typing import Dict, Any
import requests
import base64
import purge
import re
from bc_release import ReleaseGenerator
from flask import Flask, request,Response
import prefetch
import gmtool_csv_purge
import gmtool_upload
import cdn_upload
import gmtool_update
import server_update
import guideme
import manage_statefulsets
import check_file
import release_content
import asyncio
from collections import deque

#设置固定大小的队列长度
max_events = 20
processed_event_ids = deque(maxlen=max_events)

# settings
SIGNING_SECRET = b"lbp4LpRtR_73FToDWVSJGyXMBzvlnAWZ" ##可在bot回调设置页面获取
HOST = "0.0.0.0"
PORT = 19091
 
# event list
# ref: https://open.seatalk.io/docs/list-of-events
EVENT_VERIFICATION = "event_verification"
NEW_BOT_SUBSCRIBER = "new_bot_subscriber"
MESSAGE_FROM_BOT_SUBSCRIBER = "message_from_bot_subscriber"
INTERACTIVE_MESSAGE_CLICK = "interactive_message_click"
BOT_ADDED_TO_GROUP_CHAT = "bot_added_to_group_chat"
BOT_REMOVED_FROM_GROUP_CHAT = "bot_removed_from_group_chat"
NEW_MENTIONED_MESSAGE_RECEIVED_FROM_GROUP_CHAT = "new_mentioned_message_received_from_group_chat"
NEW_MENTIONED_MESSAGE_FROM_GROUP_CHAT = "new_mentioned_message_received_from_group_chat"
 
app = Flask(__name__)
 
 
def is_valid_signature(signing_secret: bytes, body: bytes, signature: str) -> bool:
    # ref: https://open.seatalk.io/docs/server-apis-event-callback
    return hashlib.sha256(body + signing_secret).hexdigest() == signature

def get_accesstoken_generate_header():
    url = "https://openapi.seatalk.io/auth/app_access_token"

    data = {
        "app_id": "MTQ2NDY3MzI2NDM5",
        "app_secret": "Cq7dsvjlKCQu-TxhNQaELv8ZfyzEX__z"
    }

    response = requests.post(url, json=data)
    response_data = response.json()
    token = response_data.get("app_access_token")
    headers = {
        'Authorization': 'Bearer ' + token,
        'Content-Type': 'application/json'
    }
    return headers
 
#send message to subscriber

def send_msg_to_subscriber(eid, headers, content):
    headers = dict(headers)
    message = {
        #'group_id':"MzEyNzMxMjI2Mjg2",
        'employee_code': eid,
        'message':
            {
                'tag': 'text',
                'text': {
                    'format':1,
                    'content':f'```{content}```'
                }
            }
    }

    print(headers)
    print(content)
    # 发送POST请求
    response = requests.post('https://openapi.seatalk.io/messaging/v2/single_chat', headers=headers, json=message)
    #response_group = requests.post('https://openapi.seatalk.io/messaging/v2/group_chat', headers=headers, json=message)

    # 检查响应状态码
    if response.status_code == 200:
        print('消息发送成功')
    else:
        print(f'消息发送失败，状态码为{response.status_code}')


#send message to group

def send_msg_to_group(gid,headers,content,thread_id=None,quoted_message_id=None):
    headers = dict(headers)
    if thread_id:
        message = {
            "group_id": gid,
            "message": {
                "tag": 'text',
                "text": {
                    "format":1,
                    "content": f'```{content}```'
                },
                "thread_id": thread_id,
                "quoted_message_id":quoted_message_id
            }
        }
    else:
        message = {
            "group_id":gid,
            #'employee_code': eid,
            "message":
                {
                    "tag": 'text',
                    "text": {
                        "format":1,
                        "content": f'```{content}```'
                    }
                }
        }

    print(headers)
    print(content)

    # 发送POST请求
    #response = requests.post('https://openapi.seatalk.io/messaging/v2/single_chat', headers=headers, json=message)
    response_group = requests.post('https://openapi.seatalk.io/messaging/v2/group_chat', headers=headers, json=message)

    # 检查响应状态码
    if response_group.status_code == 200:
        print(response_group.text)
        print('消息发送成功')
    else:
        print(f'消息发送失败，状态码为{response_group.status_code}')

#send image to group chat
#def send_image_to_group(gid,headers,folder,thread_id=None,quoted_message_id=None):
#    headers = dict(headers)
#     # 遍历目录中的所有文件
#    for filename in os.listdir(folder):
#        filepath = os.path.join(folder, filename)
#        
#        if os.path.isfile(filepath):  # 只处理文件
#            # 检测文件的 MIME 类型
#            mime_type, _ = mimetypes.guess_type(filepath)
#            
#            if mime_type and mime_type.startswith('image/'):
#                with open(filepath, 'rb') as img_file:
#                    # 读取图片内容
#                    img_content = img_file.read()
#  
#                # 进行Base64编码
#                encoded_img = base64.b64encode(img_content).decode("utf-8")
#                message = {
#                    "group_id":gid,
#                    "message":
#                        {
#                            "tag": 'image',
#                            "image": {
#                                 "content":'{}'.format(encoded_img)
#                            },
#                            "thread_id": thread_id,
#                            "quoted_message_id":quoted_message_id
#                        }
#                }
#
#                print(headers)
#                #print(encoded_img)
#
#                # 发送POST请求
#                #response = requests.post('https://openapi.seatalk.io/messaging/v2/single_chat', headers=headers, json=message)
#                response_group = requests.post('https://openapi.seatalk.io/messaging/v2/group_chat', headers=headers, json=message)
#                # 检查响应状态码
#                if response_group.status_code != 200:
#                    return f"Error: Failed to send image {filename}. Status code: {response_group.status_code}, Response: {response_group.json()}"
#            else:
#                return f"Error: {filename} is not an image file."
#    return "All images sent successfully."

def send_image_to_group(gid, headers, folder, thread_id=None, quoted_message_id=None):
    headers = dict(headers)
    error_messages = []

    # 遍历目录中的所有文件
    for filename in os.listdir(folder):
        filepath = os.path.join(folder, filename)
        print (filename)
        if os.path.isfile(filepath):  # 只处理文件
            # 检测文件的 MIME 类型

            if filename.lower().endswith('.png'):
                with open(filepath, 'rb') as img_file:
                    # 读取图片内容
                    img_content = img_file.read()

                # 进行Base64编码
                encoded_img = base64.b64encode(img_content).decode("utf-8")
                message = {
                    "group_id": gid,
                    "message": {
                        "tag": 'image',
                        "image": {
                            "content": '{}'.format(encoded_img)
                        },
                        "thread_id": thread_id,
                        "quoted_message_id": quoted_message_id
                    }
                }

                print(headers)
                # 发送POST请求
                response_group = requests.post('https://openapi.seatalk.io/messaging/v2/group_chat', headers=headers, json=message)
                time.sleep(2)
                # 检查响应状态码
                if response_group.status_code != 200:
                    error_messages.append(f"Error: Failed to send image {filename}. Status code: {response_group.status_code}, Response: {response_group.json()}")
            else:
                error_messages.append(f"Error: {filename} is not an image file.")

    if error_messages:
        return "Some errors occurred: " + "; ".join(error_messages)
    else:
        return "All images sent successfully."

#个人发送卡片交互信息
def send_interactive_msg_to_group(gid,headers,content,thread_id,quoted_message_id=None):
    headers = dict(headers)
    if thread_id: 
        message = {
        "group_id": gid,
        "message":{
            "tag":"interactive_message",
            "interactive_message":{
                "elements":[
                    {
                        "element_type":"title",
                        "title":{
                            "text":"🟢  BCM 更新发布确认单"
                        }
                    },
                    {
                        "element_type":"description",
                        "description":{
                            "format":1,
                            "text":content
                        }
                    },
                    {
                        "element_type":"button",
                        "button":{
                            "button_type":"callback",
                            "text":"发布单正确,请执行",
                            "value":"approve"
                        }

                    },
                    {
                        "element_type":"button",
                        "button":{
                            "button_type":"callback",
                            "text":"发布单有误,请取消",
                            "value":"reject"
                        }
                    }
            
                ]
            },
            "thread_id":thread_id,
            "quoted_message_id":quoted_message_id
        }
    }
    else:
         message = {
        "group_id": gid,
        "message":{
            "tag":"interactive_message",
            "interactive_message":{
                "elements":[
                    {
                        "element_type":"title",
                        "title":{
                            "text":"🟢  BCM 更新发布确认单"
                        }
                    },
                    {
                        "element_type":"description",
                        "description":{
                            "format":1,
                            "text":content
                        }
                    },
                    {
                        "element_type":"button",
                        "button":{
                            "button_type":"callback",
                            "text":"发布单正确,请执行",
                            "value":"approve"
                        }

                    },
                    {
                        "element_type":"button",
                        "button":{
                            "button_type":"callback",
                            "text":"发布单有误,请取消",
                            "value":"reject"
                        }
                    }

                ]
            }
        }
    }
    print(headers)
    #print(content)
    # 发送POST请求
    #response = requests.post('https://openapi.seatalk.io/messaging/v2/single_chat', headers=headers, json=message)
    response_group = requests.post('https://openapi.seatalk.io/messaging/v2/group_chat', headers=headers, json=message)

    # 检查响应状态码
    if response_group.status_code == 200:
        print('消息发送成功')
    else:
        print(f'消息发送失败，状态码为{response.status_code}')
  
    return response_group.json()

def process_context_data(cleaned_data):
    if "[UPDATE ENV]" in cleaned_data and "[GMTool CSV]" in cleaned_data and "[GMTool CSV MD5]" in cleaned_data:
        result = gmtool_upload.extract_values(cleaned_content)
        if isinstance(result, str):
            message = result
            send_msg_to_group(gid, headers, message,thread_id,quoted_message_id)
        else:
            env, csv, gmtool_folder, md5, gmtool_version_value = gmtool_upload.extract_values(cleaned_content)
            storage_location = gmtool_upload.match_environment(env)
            gmtool_tmp_directory = "/data/tools/gmtooltmp"
            extracted_directory, error_message = gmtool_upload.extract_file(csv, gmtool_tmp_directory)
            if extracted_directory is None:
                send_msg_to_group(gid, headers, error_message,thread_id,quoted_message_id)
                exit()
            else:
                print("Extraction successful. Extracted files are in:", extracted_directory)
            command = f"/data/tools/obs/obsutil_linux_amd64_5.5.9/obsutil cp {extracted_directory} {storage_location} -r -f"
            inform_message = f"Please wait while the file is being uploaded from {extracted_directory} to {storage_location}"
            send_msg_to_group(gid, headers, inform_message,thread_id,quoted_message_id)
            command = f"/data/tools/obs/obsutil_linux_amd64_5.5.9/obsutil cp {extracted_directory} {storage_location} -r -f"
            if not gmtool_upload.check_md5(csv, md5):
                output_message = "🔴 md5code is wrong, please check"
                send_msg_to_group(gid, headers, output_message,thread_id,quoted_message_id)
                exit()
            output_message = (gmtool_upload.execute_command(command))
            send_msg_to_group(gid, headers, output_message,thread_id,quoted_message_id)
            if gmtool_version_value is not None:
                file_paths = gmtool_update.get_file_paths(env)
                print(file_paths)
                for file_path in file_paths:
                    print(file_path)
                    full_file_path = os.path.join("/data/tools/seatalk/server/gm-tools", file_path)
                    gmtool_update.backup_and_update_version(full_file_path, gmtool_version_value)
                info = gmtool_update.update_files(file_paths)
                sha = info['id']
                time.sleep(15)
                pipeline_result = env + " gmtool " + gmtool_update.get_pipeline_status(sha)
                send_msg_to_group(gid, headers, pipeline_result,thread_id,quoted_message_id)
            else:
                pass

        # if "[CDN UPDATE]" in context_data and "RequireVersion" in context_data and "[AOS MD5]" in context_data or "[IOS MD5]" in context_data:
    if "[UPDATE ENV]" in cleaned_data and "RequireVersion" in cleaned_data and "[AOS MD5]" in cleaned_data or "[IOS MD5]" in cleaned_data:
        result = cdn_upload.extract_values(cleaned_content)
        if isinstance(result, str):
            message = result
            send_msg_to_group(gid, headers, message,thread_id,quoted_message_id)
        else:
            env_value, aosfile_value, iosfile_value, aosmd5_value, iosmd5_value, aos_buildtype_value, ios_buildtype_value, aos_requireversion_value, ios_requireversion_value = cdn_upload.extract_values(
                cleaned_content)
            if aosfile_value is not None:
                # check env filename buildtype requireversion
                aos_env_match_result = cdn_upload.determine_environment(aos_buildtype_value, aosfile_value,
                                                                        aos_requireversion_value, env_value)
                print(aos_requireversion_value, ios_requireversion_value)
                if aos_env_match_result is not True:
                    send_msg_to_group(gid, headers, aos_env_match_result,thread_id,quoted_message_id)
                    exit(1)
                aos_storage_location = os.path.join(cdn_upload.match_environment(env_value), "android")
                shipping_patchinfo = os.path.join(aos_storage_location, aos_buildtype_value, "Shipping",
                                                  "PatchInfo_CDI.json").replace("obs://dl-bc-cdn-garenanow-com",
                                                                                "https://dl.bc.cdn.garenanow.com")
                whitelist_patchinfo = os.path.join(aos_storage_location, aos_buildtype_value, "Shipping",

                                                   "WhiteListCDI", "PatchInfo_CDI.json").replace(
                    "obs://dl-bc-cdn-garenanow-com", "https://dl.bc.cdn.garenanow.com")
                purge_list = [shipping_patchinfo, whitelist_patchinfo]
                cdn_tmp_directory = "/data/tools/cdntmp"
                aos_extracted_directory, error_message = cdn_upload.extract_file(aosfile_value, cdn_tmp_directory,
                                                                                 aos_buildtype_value)
                if aos_extracted_directory is None:
                    send_msg_to_group(gid, headers, error_message,thread_id,quoted_message_id)
                    exit()
                else:
                    print("Extraction successful. Extracted files are in:", aos_extracted_directory)
                inform_message = f"Please wait while the file is being uploaded from {aos_extracted_directory} to {aos_storage_location}"
                send_msg_to_group(gid, headers, inform_message,thread_id,quoted_message_id)
                command = f"/data/tools/obs/obsutil_linux_amd64_5.5.9/obsutil cp {aos_extracted_directory} {aos_storage_location} -r -f"
                if not cdn_upload.check_md5(aosfile_value, aosmd5_value):
                    output_message = " 🔴 aos file md5code is wrong, please check"
                    send_msg_to_group(gid, headers, output_message,thread_id,quoted_message_id)
                    exit()
                output_message = (cdn_upload.execute_command(command))
                send_msg_to_group(gid, headers, output_message,thread_id,quoted_message_id)
                purge_message = purge.purge_akamai(purge_list)
                send_msg_to_group(gid, headers, purge_message,thread_id,quoted_message_id)
                upload_result = "🟢  AOS CND更新完成"
                send_msg_to_group(gid, headers, upload_result,thread_id,quoted_message_id)
            else:
                pass
            if iosfile_value is not None:
                ios_env_match_result = cdn_upload.determine_environment(ios_buildtype_value, iosfile_value,
                                                                        ios_requireversion_value, env_value)
                if ios_env_match_result is not True:
                    send_msg_to_group(gid, headers, ios_env_match_result,thread_id,quoted_message_id)
                    exit(1)
                ios_storage_location = os.path.join(cdn_upload.match_environment(env_value), "ios")
                shipping_patchinfo = os.path.join(ios_storage_location, ios_buildtype_value, "Shipping",
                                                  "PatchInfo_CDI.json").replace("obs://dl-bc-cdn-garenanow-com",
                                                                                "https://dl.bc.cdn.garenanow.com")
                whitelist_patchinfo = os.path.join(ios_storage_location, ios_buildtype_value, "Shipping",
                                                   "WhiteListCDI", "PatchInfo_CDI.json").replace(
                    "obs://dl-bc-cdn-garenanow-com", "https://dl.bc.cdn.garenanow.com")
                purge_list = [shipping_patchinfo, whitelist_patchinfo]
                cdn_tmp_directory = "/data/tools/cdntmp"
                ios_extracted_directory, error_message = cdn_upload.extract_file(iosfile_value, cdn_tmp_directory,
                                                                                 ios_buildtype_value)
                if ios_extracted_directory is None:
                    send_msg_to_group(gid, headers, error_message,thread_id,quoted_message_id)
                    exit()
                else:
                    print("Extraction successful. Extracted files are in:", ios_extracted_directory)
                inform_message = f"Please wait while the file is being uploaded from {ios_extracted_directory} to {ios_storage_location}"
                send_msg_to_group(gid, headers, inform_message,thread_id,quoted_message_id)
                command = f"/data/tools/obs/obsutil_linux_amd64_5.5.9/obsutil cp {ios_extracted_directory} {ios_storage_location} -r -f"
                if not cdn_upload.check_md5(iosfile_value, iosmd5_value):
                    output_message = "🔴 ios file md5code is wrong, please check"
                    send_msg_to_group(gid, headers, output_message,thread_id,quoted_message_id)
                    exit()
                output_message = (cdn_upload.execute_command(command))
                send_msg_to_group(gid, headers, output_message,thread_id,quoted_message_id)
                purge_message = purge.purge_akamai(purge_list)
                send_msg_to_group(gid, headers, purge_message,thread_id,quoted_message_id)
                upload_result = "🟢  IOS CDN更新完成"
                send_msg_to_group(gid, headers, upload_result,thread_id,quoted_message_id)
            else:
                pass

    if "[BRANCH]" in cleaned_data and "[CHART_VERSION]" in cleaned_data:
        dict_info = server_update.extract_value(cleaned_content)
        print(dict_info)
        update_env = dict_info["update_env"]
        branch = dict_info["branch"]
        chart_version = dict_info["chart_version"]
        game_servers = dict_info["game_servers"]
        pvp_servers = dict_info["pvp_servers"]
        common_servers = dict_info["common_servers"]
        all_servers = dict_info["all_servers"]
        if branch and chart_version is not None:
            # backup yml file
            file_paths = server_update.get_file_paths(update_env)
            print(file_paths)
            for file_path in file_paths:
                full_file_path = os.path.join("/data/tools/seatalk/server/games", file_path)
                server_update.backup_version(full_file_path)
                server_update.process_paths(update_env, full_file_path, branch, chart_version, game_servers,
                                            all_servers)
            info = server_update.update_yml_files(file_paths)
            sha = info['id']
            time.sleep(15)
            pipeline_result = update_env + " game services " + server_update.get_pipeline_status(sha)
            send_msg_to_group(gid, headers, pipeline_result,thread_id,quoted_message_id)
     
        else:
            pass

@app.route("/bot-callback", methods=["POST"])
def bot_callback_handler():
    global gid, headers,cleaned_content,thread_id,quoted_message_id
    body: bytes = request.get_data()
    signature: str = request.headers.get("signature")
    # 1. validate the signature
    if not is_valid_signature(SIGNING_SECRET, body, signature):
        print("Invalid signature!")
        return ""
    # 2. handle events
    data: Dict[str, Any] = json.loads(body)
    event_type: str = data.get("event_type", "")
    print (data)
    if event_type == MESSAGE_FROM_BOT_SUBSCRIBER:
        headers = get_accesstoken_generate_header()
        eid = data["event"]["employee_code"]
        content_data = data['event']['message']['text']['content']
        event_id = data["event_id"]

        # 检查event_id是否已经处理过
        if event_id in processed_event_ids:
            print(f"Event ID {event_id} is a duplicate and will not be processed.")
        else:
            # 如果event_id不重复，则将其添加到队列中，并执行后续操作
            # 当队列达到最大长度时，最旧的元素将被自动移除
            processed_event_ids.append(event_id)
            if "prefetch" in content_data:
                result = prefetch.extract_bc_build_and_gbin(content_data)
                if isinstance(result, str):
                    message = result
                    send_msg_to_subscriber(eid,headers,message)
                else:
                    message, filename, buildtype = result
                    send_msg_to_subscriber(eid,headers,message)
                    output_message = prefetch.run_prefetch(filename,buildtype)
                    send_msg_to_subscriber(eid, headers, output_message)
    elif event_type == NEW_MENTIONED_MESSAGE_FROM_GROUP_CHAT:
        eid = data["event"]["message"]["sender"]["employee_code"]
        #gid = "MTE5NDA0NjU3NzIx"
        gid = "OTQ4MTc2NzQ4MTk2"
        #gid = "MjQ1NzM3OTc0MjQw"
        context_data = data['event']['message']['text']['plain_text']
        context_data = context_data.replace("@bc_bot", "")
        # 获取 'plain_text' 值
        context_value = data['event']['message']['text']['plain_text']
        # 去除 '@codm_bot '
        cleaned_content = context_value.replace('@bc_bot ', '')
        # 更新 'content' 键的值
        data['event']['message']['text']['content'] = cleaned_content
        # 删除 'plain_text' 键
        del data['event']['message']['text']['plain_text']
       
        thread_id = data['event']['message']['thread_id']
        quoted_message_id = data['event']['message']['quoted_message_id']
        headers = get_accesstoken_generate_header()
        event_id = data["event_id"]
        if event_id in processed_event_ids:
            print(f"Event ID {event_id} is a duplicate and will not be processed.")
        else:
            # 如果event_id不重复，则将其添加到队列中，并执行后续操作
            # 当队列达到最大长度时，最旧的元素将被自动移除
            processed_event_ids.append(event_id)
            if "purge" in context_data:
                urls = purge.extract_url_from_cmd(cleaned_content)
                content = purge.purge_akamai(urls)
                send_msg_to_group(gid,headers,content,thread_id,quoted_message_id)
            elif "statefulsets" in context_data:
                env,action = manage_statefulsets.parse_input(cleaned_content)
                namespace_list = manage_statefulsets.get_namespaces(env)
                if not namespace_list:
                    message_error = f"Unknown or empty environment: {env}"
                    send_msg_to_group(gid,headers,message_error,thread_id,quoted_message_id)
                    sys.exit(0)

                results = manage_statefulsets.operate_statefulsets(namespace_list, action, env)
                send_msg_to_group(gid,headers,results,thread_id,quoted_message_id)
            elif "prefetch" in context_data:
                result = prefetch.extract_bc_build_and_gbin(cleaned_content)
                if isinstance(result, str):
                    message = result
                    send_msg_to_group(gid,headers,message,thread_id,quoted_message_id)
                else:
                    message, filename, buildtype = result
                    send_msg_to_group(gid,headers,message)
                    success_count,failure_count,log_file_path = prefetch.run_prefetch(filename,buildtype)
                    output_message = (f"Successfully prefetched {success_count} files.\n"
                      f"Failed to prefetch {failure_count} files in Asia area.\n"
                      f"Check the log for details: {log_file_path}")
                    send_msg_to_group(gid, headers, output_message,thread_id,quoted_message_id)

                    ##US region prefetch
                    prefetch.usprefetch(log_file_path)
            elif "gmtool_csv_delete" in context_data:
                result = gmtool_csv_purge.extract_bc_build_and_gbin(cleaned_content)
                if isinstance(result, str):
                    message = result
                    send_msg_to_group(gid,headers,message,thread_id,quoted_message_id)
                else:
                    message, filename, buildtype = result
                    send_msg_to_group(gid,headers,message,thread_id,quoted_message_id)
                    output_message = gmtool_csv_purge.run_prefetch(filename,buildtype)
                    send_msg_to_group(gid, headers, output_message,thread_id,quoted_message_id)
            elif "--help" in context_data or "使用指引" in context_data:
                guide_info = guideme.read_text_content()
                send_msg_to_group(gid, headers, guide_info,thread_id,quoted_message_id)
                #release_info = release_content.extract_values_v2(cleaned_content)
                #send_interactive_msg_to_group(gid,headers,release_info)
                #exit(1)
            #if "[GMTool UPDATE]" in context_data and "[GMTool CSV]" in context_data and "[GMTool CSV MD5]" in context_data:
            elif "image_check" in context_data:
                folder_list = re.findall(r'/data/home/bc_build/Webservice/HelpSystem[^ ]*?/Image',cleaned_content)
                folder = folder_list[0]
                image_result = send_image_to_group(gid,headers,folder,thread_id,quoted_message_id)
                send_msg_to_group(gid,headers,image_result,thread_id,quoted_message_id)
            elif "file_check" in context_data:
                paths = check_file.extract_path_from_cmd(cleaned_content)
                path = paths[0].replace('\xa0', '').strip()
                content = check_file.check_path(path)
                send_msg_to_group(gid,headers,content,thread_id,quoted_message_id)

            if "[UPDATE ENV]" in context_data:
                release_info = release_content.extract_values_v2(cleaned_content)
                send_interactive_msg_to_group(gid,headers,release_info,thread_id,quoted_message_id)
                
            else:
                #content = "Sorry I can not understand you, the function has not been developed yet"
                #send_msg_to_group(gid,headers,content)
                #print(content)
                pass
    elif event_type == INTERACTIVE_MESSAGE_CLICK:
         headers = get_accesstoken_generate_header()
         choice = data['event']['value']
         gid = 'OTQ4MTc2NzQ4MTk2'
         #gid = 'MjQ1NzM3OTc0MjQw'
         #context_data = data['event']['message']['text']['plain_text']
         #context_data = context_data.replace("@bc_bot", "")
        # 获取 'plain_text' 值
         #context_value = data['event']['message']['text']['plain_text']
        # 去除 '@codm_bot '
         #cleaned_content = context_value.replace('@bc_bot ', '')
        # 更新 'content' 键的值
         #data['event']['message']['text']['content'] = cleaned_content
        # 删除 'plain_text' 键
         #del data['event']['message']['text']['plain_text']
         if choice == "approve":
             process_context_data(cleaned_content)
            #send_msg_to_group(gid, headers, "已更新")
             choice = "approved"
         elif choice == "reject":
             send_msg_to_group(gid, headers, "已取消",thread_id,quoted_message_id)
             choice = "cancel"
             exit(0)
         else:
             pass
    else:
        pass
 
    return ""
@app.route('/echo', methods=['POST']) 
def echo():
    # 直接返回接收到的数据
    # 确保获取到了请求数据，并进行了解码
    data = request.data.decode('utf-8')
    groupid = request.args.get('groupid')
    if data:
        # 返回解码后的数据，并设置 MIME 类型为纯文本
        headers = get_accesstoken_generate_header()
    
        send_msg_to_group(groupid,headers,data)
        return Response(data, mimetype='text/plain')
    else:
        # 如果没有数据，返回一个错误或默认响应
        return Response("No data received", status=400) 
if __name__ == "__main__":
    app.run(host=HOST, port=PORT, debug=True)

