import subprocess
import re

def purge_akamai(urls):
    # 判断urls是否为列表
    if not isinstance(urls, list):
        return "No valid url detected, please check"
    else:
        purge_results = []
        for url in urls:
            try:
                # 构建 akamai-purge 命令
                cmd = f'akamai-purge --section default delete {url}'

                # 执行命令并获取返回码
                result = subprocess.run(cmd, shell=True, check=True)

                # 输出返回码
                print(f'{url} Purge successful. Return code: {result.returncode}')

                # 将成功信息存储到列表中
                purge_results.append(f'{url} Purge successful. Return code: {result.returncode}')

            except subprocess.CalledProcessError as e:
                # 打印错误信息
                print(f'{url} Purge failed. Return code: {e.returncode}')

                # 将失败信息存储到列表中
                purge_results.append(f'{url} Purge failed. Return code: {e.returncode}')

        # 用两个换行符连接列表中的字符串
        return "\n\n".join(purge_results)
def extract_url_from_cmd(cmd):
    # 使用正则表达式匹配URL
    match=re.findall(r'\bhttps?://\S*\b', cmd)
    if match:
        # 返回匹配url
        return match
    else:
        # 如果未找到匹配，返回None或者抛出异常，具体取决于你的需求
        return "url error, please check"

# 调用函数并传入要purge的URL
#cmd = '''purge https://dl.bc.cdn.garenanow.com/test/ios/GB_Live_IOS_QA4_2_AdHoc/patch_info.json
#       ,https://dl.bc.cdn.garenanow.com/test/ios/GB_Live_IOS_QA4_3_AdHoc/patch_info.json'''
#urls = extract_url_from_cmd(cmd)
#purge_akamai(urls)
# 打印结果码
#print(f'Result Code: {result_code}')

