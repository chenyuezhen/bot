def read_text_content():
    content = """
    🟢 bc bot 功能及使用方法 🟢
    ---------------------------------
    1.文件缓存清理
    purge ${url}   eg：purge https://dl.bc.cdn.garenanow.com/hotfix/xx.json
  
    2.关服/启服/重启服务
    statefulsets stop/start/restart ${env} eg: stop/start/restart hotfix or hotfix stop/start/restart
    stop/start/restart qa : 重启所有qa环境的所有服务
    stop/start/restart cnqa01: 只重启cnqa01的game servie(包含chat,game master服务)

    3.目录文件预热-支持新加坡美国2区同时预热
    prefetch ${cdn_file} ${remote build_type} 
    eg: prefetch /data/home/bc_build/CDN/2024xxxxx/BC_IOS_Appstore_xx.zip xxx

    4.CSV目录文件缓存清理
    gmtool_csv_delete ${cdn_file} ${env}
    eg:gmtool_csv_delete /data/home/bc_build/GMTool/csv_table/xxx.zip hotfix01

    5.GMtool 更新-支持CSV上传和version同时更新-暂不支持webservice更新
    [UPDATE ENV]:  hotfix     
    [GMTool Version]: xxxxxxxxxx
    [GMTool CSV]: /data/home/bc_build/GMTool/csv_table/xxxxx/xxxxxx.zip
    [GMTool CSV MD5]: xxxxxxxxxxxxxxxxxx

    6.CDN资源更新-支持文件名/build_type/requireversion等参数校验验证错误提示等
    [UPDATE ENV]:   hotfix    
    [AOS FILE Path]: /data/home/bc_build/CDN/xxxxx/xxxxxxxxx.zip
    [AOS MD5]: xxxxxxxxxxx
    [AOS BUILD TYPE]:xxxxxxxxxxx
    AndroidRequireVersion: xxxxxxxxxxxxxx

    7.Server更新-GAME/PVP/COMMON可以同时更新任意模块任意服务
    [UPDATE ENV]:hotfix
    [BRANCH]:gbin_s9live
    [CHART_VERSION]:1.09.119
    [GAME SERVERS]:chat-server,game-server,master-server
    [PVP SERVERS]:pvp-server,matching-server
    [COMMON SERVERS]:iap-server,api-server,region-server

    8.HelpSystem 图片展示
    image_check ${folder}
    eg:image_check /data/home/bc_build/Webservice/HelpSystem/240625/Image

    9.文件或目录检测
    file_check ${file} or file_check {folder}
    eg:file_check /data/home/bc_build/GMTool/csv_table/20240903/GB-S11Live-20240904.zip
    """
    return content
