import re
import os
import hashlib
import zipfile
import subprocess
import datetime

cdn_tmp_directory = "/data/tools/cdntmp" 
def clean_old_directories(directory):
    try:
        two_days_ago = datetime.datetime.now() - datetime.timedelta(days=2)
        # 构建 find 命令
        find_command = ["find", directory, "-type", "d", "-name", "BC_*", "-ctime", "+2", "-exec", "rm", "-rf", "{}", "+"]
        # 执行 find 命令
        subprocess.run(find_command)
    except Exception as e:
        print("An error occurred while cleaning old directories:", e)

def match_environment(environment):
    environment_lower = environment.lower()
    environment_mapping = {
        "hotfix": "obs://dl-bc-cdn-garenanow-com/hotfix",
       # "cnqa01": "obs://dl-bc-cdn-garenanow-com/test",
       # "cnqa02": "obs://dl-bc-cdn-garenanow-com/test",
       # "cnqa03": "obs://dl-bc-cdn-garenanow-com/test",
       # "cnqa04": "obs://dl-bc-cdn-garenanow-com/test",
       # "cnqa05": "obs://dl-bc-cdn-garenanow-com/test",
        "qa": "obs://dl-bc-cdn-garenanow-com/test",
        "review": "obs://dl-bc-cdn-garenanow-com/live_gb",
#        "live": "obs://dl-bc-cdn-garenanow-com/live_gb"
    }

    if environment_lower in environment_mapping:
        return environment_mapping[environment_lower]
    else:
        return "Error,unknown environment,env should be one of hotfix,review,qa,live"

def check_md5(file_path, expected_md5):
    with open(file_path, 'rb') as f:
        file_md5 = hashlib.md5(f.read()).hexdigest()
    return file_md5 == expected_md5


def extract_values(text):
    # 匹配 env
    #env_match = re.search(r'\[CDN UPDATE\]:\s*(\S+)', text,re.IGNORECASE)
    env_match = re.search(r'\[UPDATE ENV\]:\s*(\S+)', text,re.IGNORECASE)
    env_value = env_match.group(1) if env_match else None

    # 匹配 AOS FILE
    aosfile_match = re.search(r'\[AOS FILE Path\]:\s*(.*)', text,re.IGNORECASE)
    aosfile_value = aosfile_match.group(1).strip() if aosfile_match else None
 #   aosfolder = os.path.splitext(os.path.basename(aosfile_value))[0]
    
    # 匹配 IOS FILE
    iosfile_match = re.search(r'\[IOS FILE Path\]:\s*(.*)', text,re.IGNORECASE)
    iosfile_value = iosfile_match.group(1).strip() if iosfile_match else None
 #   iosfolder = os.path.splitext(os.path.basename(iosfile_value))[0]
    # 匹配 AOS FILE MD5
    aosmd5_match = re.search(r'\[AOS MD5\]:\s*(.*)', text,re.IGNORECASE)
    aosmd5_value = aosmd5_match.group(1).strip() if aosmd5_match else None

    #匹配 IOS FILE MD5
    iosmd5_match = re.search(r'\[IOS MD5\]:\s*(.*)', text,re.IGNORECASE)
    iosmd5_value = iosmd5_match.group(1).strip() if iosmd5_match else None

    #匹配 AOS BUILD TYPE
    aos_buildtype_match = re.search(r'\[AOS BUILD TYPE\]:\s*(.*)', text,re.IGNORECASE)
    aos_buildtype_value = aos_buildtype_match.group(1).strip() if aos_buildtype_match else None

    #匹配 IOS BUILD TYPE
    ios_buildtype_match = re.search(r'\[IOS BUILD TYPE\]:\s*(.*)', text,re.IGNORECASE)
    ios_buildtype_value = ios_buildtype_match.group(1).strip() if ios_buildtype_match else None
   

    # 匹配 AndroidRequireVersion
    aos_requireversion_match = re.search(r'AndroidRequireVersion\s*:\s*(.*)', text,re.IGNORECASE)
    aos_requireversion_value = aos_requireversion_match.group(1).strip() if aos_requireversion_match else None

   # 匹配 iOSRequireVersion
    ios_requireversion_match = re.search(r'iOSRequireVersion\s*:\s*(.*)', text,re.IGNORECASE)
    ios_requireversion_value = ios_requireversion_match.group(1).strip() if ios_requireversion_match else None

    #if env_value is None or aosfile_value is None or iosfile_value is None or aosmd5_value is None or iosmd5_value is None or aos_buildtype_value is None or ios_buildtype_value is None:
    #    return "Please check for format errors"
    #return env_value, aosfile_value, iosfile_value,aosmd5_value,iosmd5_value,aos_buildtype_value,ios_buildtype_value
    if env_value is None:
        #return "Please check for format errors regarding CDN UPDATE, env not correct."
        return "Please check for format errors regarding UPDATE ENV, env not correct."
    elif aosfile_value and aos_buildtype_value and ("aos" not in aosfile_value.lower() or "aos" not in aos_buildtype_value.lower()):
        return "Aos file or buildtype not contain aos string,please check"
    elif iosfile_value and ios_buildtype_value and ("ios" not in iosfile_value.lower() or "ios" not in ios_buildtype_value.lower()):
        return "Ios file or buildtype not contain ios string, please check"
    else:
        return env_value, aosfile_value, iosfile_value,aosmd5_value,iosmd5_value,aos_buildtype_value,ios_buildtype_value,aos_requireversion_value,ios_requireversion_value
  #      return {
  #      'env': env_value,
  #      'aos_file': aosfile_value,
  #      'aos_folder': aosfolder,
  #      'aos_md5': aosmd5_value,
  #      'aos_build_type': aos_buildtype_value,
  #      'ios_file': iosfile_value,
  #      'ios_folder': iosfolder,
  #      'ios_md5': iosmd5_value,
  #      'ios_build_type': ios_buildtype_value
  #  }
def extract_file(file_path, cdn_tmp_directory,buildtype):
    try:
        # 获取文件名（不包括扩展名）
        file_name = os.path.splitext(os.path.basename(file_path))[0]
        #清理2天以前的临时旧文件
        clean_old_directories(cdn_tmp_directory)
        # 创建解压目录
        extract_directory = os.path.join(cdn_tmp_directory, file_name, buildtype)
        os.makedirs(extract_directory, exist_ok=True)

        # 解压文件
        with zipfile.ZipFile(file_path, 'r') as zip_ref:
            zip_ref.extractall(extract_directory)

        return extract_directory,None
    except Exception as e:
        return None,str(e)

#check env file_name requireversion buil_name relationship

def determine_environment(build_type, file_name, require_version, env):
    # Determine environment based on build_type
    if "GQA" in build_type:
        build_type_env = "qa"
    elif "LIVEQA" in build_type:
        build_type_env = "hotfix"
    elif "Appstore" in build_type or "Distribution" in build_type:
        build_type_env = ["live", "review"]
    else:
        build_type_env = None

    # Determine environment based on file_name
    if "Appstore" in file_name:
        file_name_env = ["live", "review"]
    elif "Shipping" in file_name:
        file_name_env = ["qa", "hotfix"]
    else:
        file_name_env = None

    # Determine environment based on require_version
    try:
        third_version_digit = require_version.split('.')[2]
        if third_version_digit.endswith('9'):
            require_version_env = ["live", "review"]
        elif third_version_digit.endswith('8'):
            require_version_env = "hotfix"
        elif third_version_digit.endswith('7'):
            require_version_env = "qa"
        else:
            require_version_env = None
    except IndexError:
        require_version_env = None

    # Validate environment consistency
    if env not in (build_type_env if isinstance(build_type_env, list) else [build_type_env]):
        return (f"Error: build_type environment does not match given env '{env}'. "
                f"build_type '{build_type}' should contain 'GQA' for qa, 'LIVEQA' for hotfix, or 'Appstore'/'Distribution' for live/review.")
    if env not in (file_name_env if isinstance(file_name_env, list) else [file_name_env]):
        return (f"Error: file_name environment does not match given env '{env}'. "
                f"file_name '{file_name}' should contain 'Appstore' for live/review or 'Shipping' for qa/hotfix.")
    if env not in (require_version_env if isinstance(require_version_env, list) else [require_version_env]):
        return (f"Error: require_version environment does not match given env '{env}'. "
                f"require_version '{require_version}' should have a third digit ending in '9' for live/review, "
                f"'8' for hotfix, or '7' for qa.")

    #return f"Environment '{env}' is valid for the given parameters."
    print (build_type, file_name, require_version, env)
    return True



def execute_command(command):
    # 执行命令并捕获输出
    result = subprocess.run(command, shell=True, capture_output=True, text=True)
    result.stdout=str(result.stdout)
    result.stdout='\n'.join([line for line in result.stdout.splitlines() if line.strip()])
    return result.stdout

