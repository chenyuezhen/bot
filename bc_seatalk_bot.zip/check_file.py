import os
import hashlib
import re
def get_md5(file_path):
    """计算文件的 MD5 值"""
    with open(file_path, 'rb') as f:
        md5 = hashlib.md5()
        while chunk := f.read(8192):
            md5.update(chunk)
        return md5.hexdigest()

def check_path(path):

    """检查路径是文件还是目录，并返回相应的结果"""
    if not os.path.exists(path):
        return f"路径 '{path}' 不存在"

    if os.path.isdir(path):
        # 处理目录
        files = os.listdir(path)
        return f"目录 '{path}' 存在，文件列表: {', '.join(files)}"

    elif os.path.isfile(path):
        # 处理文件
        file_md5 = get_md5(path)
        result = f"文件 '{path}' 存在，MD5: {file_md5}; "

        # 根据文件名称判断不同的类型
        file_name = os.path.basename(path)
        if 'csv_table' in file_name:
            result += "这是一个 gmtool CSV 文件; "
        if 'Appstore' in file_name:
            result += "🔴这是一个正式服或审核服文件;请注意 "
        if 'Shipping' in file_name:
            result += "🟢这是一个 QA 或 hotfix 服文件; "

        return result
    else:
        return f"'{path}' 不是文件也不是目录"

def extract_path_from_cmd(cmd):
    # 使用正则表达式匹配 Linux 风格的文件或目录路径
    #match = re.findall(r'\b\/(?:[^\/\s]+\/)*[^\/\s]*', cmd)
    match = re.findall(r'/[^/\s]+(?:/[^/\s]+)*', cmd)

    if match:
        # 返回匹配的路径
        return match
    else:
        # 如果未找到匹配，返回错误提示
        return "未检测到目录或文件, 请检查"

#if __name__ == "__main__":
#    # 从命令行获取路径参数
#    if len(sys.argv) != 2:
#        print("请提供文件或目录路径作为参数。")
#    else:
#        path_to_check = sys.argv[1]  # 从命令行参数中获取路径
#        check_path(path_to_check)

