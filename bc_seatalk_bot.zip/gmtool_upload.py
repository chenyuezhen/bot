import re
import os
import hashlib
import zipfile
import subprocess
import datetime

gmtool_tmp_directory = "/data/tools/gmtooltmp" 
def clean_old_directories(directory):
    try:
        two_days_ago = datetime.datetime.now() - datetime.timedelta(days=2)
        # 构建 find 命令
        find_command = ["find", directory, "-type", "d", "-name", "GB*", "-ctime", "+2", "-exec", "rm", "-rf", "{}", "+"]
        # 执行 find 命令
        subprocess.run(find_command)
    except Exception as e:
        print("An error occurred while cleaning old directories:", e)
def match_environment(environment):
    environment_lower = environment.lower()
    environment_mapping = {
        "hotfix": "obs://dl-bc-cdn-garenanow-com/csv/hotfix01",
        "review": "obs://dl-bc-cdn-garenanow-com/csv/review_gb",
     #   "cnqa01": "obs://dl-bc-cdn-garenanow-com/csv/cnqa01",
     #   "cnqa02": "obs://dl-bc-cdn-garenanow-com/csv/cnqa01",
     #   "cnqa03": "obs://dl-bc-cdn-garenanow-com/csv/cnqa01",
     #   "cnqa04": "obs://dl-bc-cdn-garenanow-com/csv/cnqa01",
     #   "cnqa05": "obs://dl-bc-cdn-garenanow-com/csv/cnqa01",
     #   "cnqa01-05": "obs://dl-bc-cdn-garenanow-com/csv/cnqa01",
        "qa": "obs://dl-bc-cdn-garenanow-com/csv/cnqa01",
        "live": "obs://dl-bc-cdn-garenanow-com/csv/global"
    }

    if environment_lower in environment_mapping:
        return environment_mapping[environment_lower]
    else:
        return "🔴 Error,unknown environment,env should be one of hotfix,review,cnqa01-05,live"

def check_md5(file_path, expected_md5):
    with open(file_path, 'rb') as f:
        file_md5 = hashlib.md5(f.read()).hexdigest()
    return file_md5 == expected_md5


def extract_values(text):
    # 匹配 env
    #env_match = re.search(r'\[GMTool UPDATE\]:\s*(\S+)', text,re.IGNORECASE)
    env_match = re.search(r'\[UPDATE ENV\]:\s*(\S+)', text,re.IGNORECASE)
    env_value = env_match.group(1) if env_match else None
    
    #Match Gmtool version
    #gmtool_version = re.search(r'\[GMTool Version\]:\s*(\S+)', text)
    #gmtool_version_value = gmtool_version.group(1) if gmtool_version else None
    gmtool_version_value=re.search(r'\[GMTool Version\]:\s*([^\[\]\s]+)', text).group(1) if re.search(r'\[GMTool Version\]:\s*([^\[\]\s]+)',text,re.IGNORECASE) else None
    # 匹配 GMTool CSV
    csv_match = re.search(r'\[GMTool CSV\]:\s*(.*)', text,re.IGNORECASE)
    csv_value = csv_match.group(1).strip() if csv_match else None

    gmtool_folder = os.path.splitext(os.path.basename(csv_value))[0]
    # 匹配 GMTool CSV MD5
    md5_match = re.search(r'\[GMTool CSV MD5\]:\s*(.*)', text,re.IGNORECASE)
    md5_value = md5_match.group(1).strip() if md5_match else None
    
    if env_value is None or csv_value is None or md5_value is None or gmtool_folder is None:
        return "🔴 Please check for format errors"

   
    return env_value, csv_value, gmtool_folder,md5_value,gmtool_version_value
def extract_file(file_path, gmtool_tmp_directory):
    try:
        # 获取文件名（不包括扩展名）
        file_name = os.path.splitext(os.path.basename(file_path))[0]
        #清理2天前临时旧文件
        clean_old_directories(gmtool_tmp_directory)
        # 创建目标目录
        extract_directory = os.path.join(gmtool_tmp_directory, file_name, 'table')
        os.makedirs(extract_directory, exist_ok=True)

        # 解压文件
        with zipfile.ZipFile(file_path, 'r') as zip_ref:
            zip_ref.extractall(extract_directory)

        return extract_directory,None
    except Exception as e:
        return None,str(e)
def execute_command(command):
    # 执行命令并捕获输出
    result = subprocess.run(command, shell=True, capture_output=True, text=True)
    result.stdout=str(result.stdout)
    result.stdout='\n'.join([line for line in result.stdout.splitlines() if line.strip()])
    return result.stdout

