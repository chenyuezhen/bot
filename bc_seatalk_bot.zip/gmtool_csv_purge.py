import os
import sys
from zipfile import ZipFile
from datetime import datetime
import subprocess
import re
#import datetime
def run_prefetch(file_path, build_type):
    prefetch_dir = "/data/tools/cdn_prefetch"
    #清理2天以前的临时文件
    #two_days_ago = datetime.datetime.now() - datetime.timedelta(days=2)
    # 构建 find 命令
    find_command = ["find", prefetch_dir, "-type", "d", "-name", "unzip*", "-ctime", "+2", "-exec", "rm", "-rf", "{}", "+"]
     # 执行 find 命令
    subprocess.run(find_command)
    # 创建一个唯一的日志文件名和解压目录名，包含当前的日期和时间
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file_name = f"prefetch_{timestamp}.log"
    unzip_dir_name = f"unzip_{timestamp}"
    log_file_path = os.path.join(prefetch_dir, log_file_name)
    unzip_dir_path = os.path.join(prefetch_dir, unzip_dir_name)

    # 拷贝并解压文件到新创建的唯一目录
    try:
        os.makedirs(unzip_dir_path, exist_ok=True)
        with ZipFile(file_path, 'r') as zip_ref:
            zip_ref.extractall(unzip_dir_path)
    except Exception as e:
        output_message=f"Error copying and extracting the file: {e}"
        sys.exit(1)

    # 确定URL前缀
    if 'GMTool' in file_path:
        url_prefix = f"https://dl.bc.cdn.garenanow.com/csv/{build_type}/table"
    else:
         output_message = "Error: The filename must contain GMTool"
         sys.exit(1)

    # 获取刚刚解压的目录中的所有文件
    files_to_prefetch = []
    for root, dirs, files in os.walk(unzip_dir_path):
        for file in files:
            files_to_prefetch.append(os.path.join(root, file))

    # 打开日志文件准备写入
    with open(log_file_path, 'w') as log_file:
        # 遍历所有文件，替换路径并写入日志
        for file_path in files_to_prefetch:
            file_url = file_path.replace(unzip_dir_path, url_prefix)
            log_file.write(file_url + '\n')

    # 初始化成功和失败预热文件计数器
    success_count = 0
    failure_count = 0

    # 遍历所有文件并使用curl进行预热
    for file_path in files_to_prefetch:
        file_url = file_path.replace(unzip_dir_path, url_prefix)
        result = subprocess.run(['akamai-purge', '--section', 'default', 'delete', file_url], capture_output=True, text=True)
       # http_status = result.stdout.strip()
        http_status =  result.returncode
        
        with open(log_file_path, 'a') as log_file:
            log_file.write(f"{file_url} HTTP_STATUS: {http_status}\n")
        
        if http_status == 0:
            success_count += 1
        else:
            failure_count += 1

    # 打印输出成功和失败预热文件总数
    output_message = (f"Successfully prefetched {success_count} files.\n"
                      f"Failed to prefetch {failure_count} files.\n"
                      f"Check the log for details: {log_file_path}")
    return output_message
def extract_bc_build_and_gbin(text):
    # 使用正则表达式来精确匹配 'GMTool' 和 'cnqa01/global' 及其后面的路径或标识
    bc_build_match = re.search(r'/data/.*?/GMTool/.*?\.zip', text)
    gbin_match = re.search(r'\b(cnqa01|global|hotfix01|review_gb)\b', text)

    # 如果找到了匹配的字符串，则提取它们
    bc_build_part = bc_build_match.group(0) if bc_build_match else None
    gbin_part = gbin_match.group(1) if gbin_match else None

    # 检查是否找到了包含 'bc_build' 和 'GBIN' 的字符串
    if not bc_build_part or not gbin_part:
        return "Invalid parameters: 'filename' or 'env' wrong ,env should be one of cnqa01/hotfix01/review_gb/global and file must contains GMTool, Please check."
    else:
        message = "GMTool CSV files purging, please wait for a while"
        # 返回包含消息和匹配字符串的元组
        return (message, bc_build_part, gbin_part)
