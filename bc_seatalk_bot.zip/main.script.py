from bc_release import ReleaseGenerator

# Assuming you have the 'text' variable defined somewhere in your script
text = '''[DATE:BCM UPDATE LIST-Add chat channel chating restrictions ]
--------------------------------------------------------------------------
UPDATE OS: AOS-1.02.107;IOS-1.02.107
UPDTATE ENV: CNQA02,CNQA03,CNQA04,CNQA05
---------------------------------------------------------------------------
GMTool UPDATE:Yes/No
GMTool CSV: 20240103/GB-S3-20240103.zip
GMTool CSV MD5:da54972557415edf6d6d5de518d71240
---------------------------------------------------------------------------
CDN UPDATE:Yes/No
AOS FILE Path:20240103/BC_IOS_Shipping_182815.zip
AOS MD5:6b9a36a7ec22ecaf787f8137d3796195
AOS BUILD TYPE: BC_AOS_GBIN_S3QA_Shipping_GQA
IOS FILE Path:20240103/BC_IOS_Shipping_182815.zip
IOS MD5:42ef8475d0c5db971794bb57bebe5522
IOS BUILD TYPE:BC_iOS_GBIN_S3QA_Adhoc_GQA
-----------------------------------------------------------------------------
DB UPDATE:Yes/No
GB DB Script Path :20231220/20231220_CA-Live_delete_item.zip
GB DB Script MD5:  7a116e5fb8e6e649399e876c9bc819e7
-----------------------------------------------------------------------------
SERVRE UPDATE:Yes/No
SERVER MODULE:All/GAMESERVER
SERVER HELM CHART UPDATE :https://drive.google.com/drive/folders/1IPNdUIyt4o3SMMZPMEHbBsJqYJwYT4Ss'''
# Replace this with the actual text

# Create an instance of ReleaseGenerator
release_generator = ReleaseGenerator(text)

# Call the method to generate the release content
release_confirm_content_string, release_confirm_content_dict = release_generator.generate_release_confirm_content()

# Print or use the string and dictionary as needed
print("Formatted String:")
print(release_confirm_content_string)

print("\nDictionary:")
print(release_confirm_content_dict)

