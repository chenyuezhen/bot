import re
import requests
import json
import sys
import os
import time
import shutil
import subprocess
from datetime import datetime

# GitLab API token
GITLAB_API_TOKEN = "hxwsW-TyexsPcPBwCmLf"

# GitLab project ID (URL-encoded if needed)
PROJECT_ID = "gre-bc%2Fbc-in-k8s"
# Mapping of environments to their corresponding file paths
env_files = {
    "qa": [
        "qa/global/cnqa01/.gitlab-ci.yml",
        "qa/global/cnqa02/.gitlab-ci.yml",
        "qa/global/cnqa03/.gitlab-ci.yml",
        "qa/global/cnqa04/.gitlab-ci.yml",
        "qa/global/cnqa05/.gitlab-ci.yml",
        "qa/global/cnqacommon/.gitlab-ci.yml"
    ],
    #"qacommon":["qa/global/cnqacommon/.gitlab-ci.yml"],
    "hotfix": ["hotfix/hotfix01/.gitlab-ci.yml",
               "hotfix/hotfixcommon/.gitlab-ci.yml"],
    #"hotfixcommon":["hotfix/hotfixcommon/.gitlab-ci.yml"],
    "pr": ["pr/.gitlab-ci.yml"],
    "review": ["review/global/.gitlab-ci.yml"],
}

def backup_version(file_path):
     # Check file_path and execute corresponding curl command
    base_url = "https://gitlab.garena.com/api/v4/projects/gre-bc%2Fbc-in-k8s/repository/files/"
    token = "hxwsW-TyexsPcPBwCmLf"
    base_local_path = "/data/tools/seatalk/server/games/"

    def execute_curl(remote_path, local_path):
        url = f"{base_url}{remote_path}/raw?ref=master"
        curl_command = f'curl --header "PRIVATE-TOKEN: {token}" "{url}" -o {local_path}'
        subprocess.run(curl_command, shell=True)
        print(f"Executed: {curl_command}")

    if "cnqa01" in file_path:
        remote_path = "games%2Fqa%2Fglobal%2Fcnqa01%2F%2Egitlab-ci%2Eyml"
        local_path = os.path.join(base_local_path, "qa/global/cnqa01/.gitlab-ci.yml")
        execute_curl(remote_path, local_path)
    elif "cnqa02" in file_path:
        remote_path = "games%2Fqa%2Fglobal%2Fcnqa02%2F%2Egitlab-ci%2Eyml"
        local_path = os.path.join(base_local_path, "qa/global/cnqa02/.gitlab-ci.yml")
        execute_curl(remote_path, local_path)
    elif "cnqa03" in file_path:
        remote_path = "games%2Fqa%2Fglobal%2Fcnqa03%2F%2Egitlab-ci%2Eyml"
        local_path = os.path.join(base_local_path, "qa/global/cnqa03/.gitlab-ci.yml")
        execute_curl(remote_path, local_path)
    elif "cnqa04" in file_path:
        remote_path = "games%2Fqa%2Fglobal%2Fcnqa04%2F%2Egitlab-ci%2Eyml"
        local_path = os.path.join(base_local_path, "qa/global/cnqa04/.gitlab-ci.yml")
        execute_curl(remote_path, local_path)
    elif "cnqa05" in file_path:
        remote_path = "games%2Fqa%2Fglobal%2Fcnqa05%2F%2Egitlab-ci%2Eyml"
        local_path = os.path.join(base_local_path, "qa/global/cnqa05/.gitlab-ci.yml")
        execute_curl(remote_path, local_path)
    elif "cnqacommon" in file_path:
        remote_path = "games%2Fqa%2Fglobal%2Fcnqacommon%2F%2Egitlab-ci%2Eyml"
        local_path = os.path.join(base_local_path, "qa/global/cnqacommon/.gitlab-ci.yml")
        execute_curl(remote_path, local_path)
    elif "hotfix01" in file_path:
        remote_path = "games%2Fhotfix%2Fhotfix01%2F%2Egitlab-ci%2Eyml"
        local_path = os.path.join(base_local_path, "hotfix/hotfix01/.gitlab-ci.yml")
        execute_curl(remote_path, local_path)
    elif "hotfixcommon" in file_path:
        remote_path = "games%2Fhotfix%2Fhotfixcommon%2F%2Egitlab-ci%2Eyml"
        local_path = os.path.join(base_local_path, "hotfix/hotfixcommon/.gitlab-ci.yml")
        execute_curl(remote_path, local_path)
    elif "review" in file_path:
        remote_path = "games%2Freview%2Fglobal%2F%2Egitlab-ci%2Eyml"
        local_path = os.path.join(base_local_path, "review/global/.gitlab-ci.yml")
        execute_curl(remote_path, local_path)
    elif "pr" in file_path:
        remote_path = "games%2Fpr%2F%2Egitlab-ci%2Eyml"
        local_path = os.path.join(base_local_path, "pr/.gitlab-ci.yml")
        execute_curl(remote_path, local_path)
     # Backup the file
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    backup_path = f"{file_path}.{timestamp}.bak"
    shutil.copy2(file_path, backup_path)
    print(f"Backup created for {file_path} at {backup_path}")



# 提取变量的函数
def extract_value(config_text):
    def extract_values(pattern, conifg_text):
        match = re.search(pattern, config_text)
        return match.group(1) if match else None

    # 提取并处理变量
#    update_env = extract_values(r'\[UPDATE ENV\]:(\S+)', config_text)
#    branch = extract_values(r'\[BRANCH\]:(\S+)', config_text)
#    chart_version = extract_values(r'\[CHART_VERSION\]:(\S+)', config_text)
#    game_servers = extract_values(r'\[GAME SERVERS\]:(\S+)', config_text)
#    game_servers = game_servers.split(',') if game_servers else []
#    pvp_servers = extract_values(r'\[PVP SERVERS\]:(\S+)', config_text)
#    pvp_servers = pvp_servers.split(',') if pvp_servers else []
#    common_servers = extract_values(r'\[COMMON SERVERS\]:(\S+)', config_text)
#    common_servers = common_servers.split(',') if common_servers else []
    update_env = extract_values(r'\[UPDATE ENV\]\s*:\s*(\S+)', config_text)
    branch = extract_values(r'\[BRANCH\]\s*:\s*(\S+)', config_text)
    chart_version = extract_values(r'\[CHART_VERSION\]\s*:\s*(\S+)', config_text)
    game_servers = extract_values(r'\[GAME SERVERS\]\s*:\s*(\S+)', config_text)
    game_servers = game_servers.split(',') if game_servers else []
    pvp_servers = extract_values(r'\[PVP SERVERS\]\s*:\s*(\S+)', config_text)
    pvp_servers = pvp_servers.split(',') if pvp_servers else []
    common_servers = extract_values(r'\[COMMON SERVERS\]\s*:\s*(\S+)', config_text)
    common_servers = common_servers.split(',') if common_servers else []
    # 合并所有服务器列表
    all_servers = game_servers + pvp_servers + common_servers
    # 返回所有提取的值
    return {
        'update_env': update_env,
        'branch': branch,
        'chart_version': chart_version,
        'game_servers': game_servers,
        'pvp_servers': pvp_servers,
        'common_servers': common_servers,
        'all_servers': all_servers
    }


# 修改文件内容的函数
def update_file(local_file_path, branch, chart_version, servers):
    # 读取文件内容
    with open(local_file_path, 'r') as file:
        lines = file.readlines()
    
    # 修改文件内容
    for i, line in enumerate(lines):
        for server in servers:
            if f'chart_name: {server}' in line:
                # 修改上一行的helm_repository版本
                helm_repository_line_index = i - 1
                if 'helm_repository' in lines[helm_repository_line_index]:
                    lines[helm_repository_line_index] = re.sub(r'gbin_s\d+\S*', branch, lines[helm_repository_line_index])
                else:
                    print("helm_repository not found in the expected line")

                # 修改下一行的chart_version
                version_line_index = i + 1
                if 'chart_version' in lines[version_line_index]:
                    lines[version_line_index] = re.sub(r'chart_version: \d+\.\d+\.\d+', f'chart_version: {chart_version}', lines[version_line_index])
                else:
                    print("chart_version not found in the expected line")

    # 写回文件
    with open(local_file_path, 'w') as file:
        file.writelines(lines)

# 更新指定的文件
def process_paths(update_env,paths, branch, chart_version, game_servers, all_servers):
     # 根据环境变量定义文件路径
    paths = {}
    if update_env == 'hotfix':
        paths = {
            'game': '/data/tools/seatalk/server/games/hotfix/hotfix01/.gitlab-ci.yml',
            'common': '/data/tools/seatalk/server/games/hotfix/hotfixcommon/.gitlab-ci.yml'
        }
    elif update_env == 'qa':
        game_paths = [f'/data/tools/seatalk/server/games/qa/global/cnqa{i:02d}/.gitlab-ci.yml' for i in range(1, 6)]
        common_path = '/data/tools/seatalk/server/games/qa/global/cnqacommon/.gitlab-ci.yml'
        paths = {'game': game_paths, 'common': common_path}
    elif update_env == 'review':
         paths = {'all': '/data/tools/seatalk/server/games/review/global/.gitlab-ci.yml'}
    elif update_env == 'pr':
        paths = {'all': '/data/tools/seatalk/server/games/pr/.gitlab-ci.yml'}
    else:
        print ("env not correct, please check")
        exit(1)
    if branch and chart_version:
        if update_env in ['review', 'pr']:
            update_file(paths['all'], branch, chart_version, all_servers)
        elif update_env == 'hotfix':
            update_file(paths['game'], branch, chart_version, game_servers)
            update_file(paths['common'], branch, chart_version, all_servers)
        elif update_env == 'qa':
            for path in paths['game']:
                update_file(path, branch, chart_version, game_servers)
            update_file(paths['common'], branch, chart_version, all_servers)
    else:
        print("branch or chart_version is not set")

#def update_yml_file(file_path):
#    # Construct GitLab file path
#    gitlab_file_path = f"games/{file_path}"
#    full_file_path = os.path.join("/data/tools/seatalk/server/games", file_path)
#    # Read the content of the file into a variable and escape it for JSON
#    with open(full_file_path, 'r') as file:
#        file_content = file.read()
#
#    # Prepare the payload for the curl command
#    payload = {
#        "branch": "master",
#        "commit_message": f"Update {gitlab_file_path} via API",
#        "actions": [
#            {
#                "action": "update",
#                "file_path": gitlab_file_path,
#                "content": file_content
#            }
#        ]
#    }
#
#    # Make the POST request
#    response = requests.post(
#        f"https://gitlab.garena.com/api/v4/projects/{PROJECT_ID}/repository/commits",
#        headers={
#            "Content-Type": "application/json",
#            "PRIVATE-TOKEN": GITLAB_API_TOKEN
#        },
#        data=json.dumps(payload)
#    )
#
#    # Print the response
#    print(f"Response for {gitlab_file_path}: {response.text}")
# 调用函数处理文件
#process_paths(paths, branch, chart_version, game_servers, all_servers)
#print('配置文件已更新。')

def update_yml_files(file_paths):
    # List to hold all actions for the commit
    actions = []

    for file_path in file_paths:
        # Construct GitLab file path
        gitlab_file_path = f"games/{file_path}"
        full_file_path = os.path.join("/data/tools/seatalk/server/games", file_path)

        # Read the content of the file into a variable
        with open(full_file_path, 'r') as file:
            file_content = file.read()

        # Create an action for this file
        actions.append({
            "action": "update",
            "file_path": gitlab_file_path,
            "content": file_content
        })

    # Prepare the payload for the curl command
    payload = {
        "branch": "master",
        "commit_message": "Update multiple .gitlab-ci.yml files via API",
        "actions": actions
    }

    # Make the POST request
    response = requests.post(
        f"https://gitlab.garena.com/api/v4/projects/{PROJECT_ID}/repository/commits",
        headers={
            "Content-Type": "application/json",
            "PRIVATE-TOKEN": GITLAB_API_TOKEN
        },
        data=json.dumps(payload)
    )

    # Print the response
    print(f"Response: {response.text}")
    return json.loads(response.text)


def get_file_paths(env):
    return env_files.get(env)

def get_pipeline_status(sha):
    headers = {
        "PRIVATE-TOKEN":GITLAB_API_TOKEN
    }
    pipelines_url = f"https://gitlab.garena.com/api/v4/projects/2625/pipelines?sha={sha}"

    while True:
        response = requests.get(pipelines_url, headers=headers)
        if response.status_code != 200:
            error_message = f"🔴获取 Pipeline 失败: {response.status_code}"
            print(error_message)
            return error_message

        pipelines = response.json()
        print (f"this is {pipelines}")
        if not pipelines:
            error_message = "🔴未找到与该 SHA 关联的 Pipeline,yml文件版本似乎没发生变化，请检查"
            print(error_message)
            return error_message

        # 获取与 SHA 关联的 Pipeline 状态
        status = pipelines[0]['status']

        if status in ['success', 'failed', 'canceled', 'skipped']:
            break

        print(f"Pipeline 状态: {status}，等待 10 秒后继续检查...")
        time.sleep(10)

    if status == 'success':
        result_message = "更新成功🟢 "
        print(result_message)
        return result_message
    else:
        result_message = f"更新失败，状态: {status} 🔴"
        print(result_message)
        return result_message
