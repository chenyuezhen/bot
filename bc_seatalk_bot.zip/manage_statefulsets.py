import subprocess
import sys
import re
import os

def switch_context(env):
    context_map = {
        'qa': 'gke_garena-blackclover_asia-southeast1-a_bc-sg-cnqa-test',
        'cnqa01': 'gke_garena-blackclover_asia-southeast1-a_bc-sg-cnqa-test',
        'cnqa02': 'gke_garena-blackclover_asia-southeast1-a_bc-sg-cnqa-test',
        'cnqa03': 'gke_garena-blackclover_asia-southeast1-a_bc-sg-cnqa-test',
        'cnqa04': 'gke_garena-blackclover_asia-southeast1-a_bc-sg-cnqa-test',
        'cnqa05': 'gke_garena-blackclover_asia-southeast1-a_bc-sg-cnqa-test',
        'hotfix': 'gke_garena-blackclover_asia-southeast1-a_bc-sg-cnqa-test',
        'review': 'gke_garena-blackclover_us-east1-c_bc-us-review-pr-k8s-cluster',
        'kol': 'gke_garena-blackclover_us-east1-c_bc-us-review-pr-k8s-cluster',
        'pr': 'gke_garena-blackclover_us-east1-c_bc-us-review-pr-k8s-cluster'
    }
    context = context_map.get(env)
     # 确保 kubectl 使用正确的配置文件
    os.environ['KUBECONFIG'] = '/root/.kube/config'
    if not context:
        print(f"Unknown environment: {env}")
        sys.exit(1)
    subprocess.run(["/usr/local/bin/kubectl", "config", "use-context", context], check=True)

def scale_statefulsets(namespace, replicas):
    statefulsets = get_statefulsets(namespace)
    for sts in statefulsets:
        subprocess.run(["/usr/local/bin/kubectl", "scale", "statefulset", sts, f"--replicas={replicas}", "-n", namespace], check=True)

def get_statefulsets(namespace):
    result = subprocess.run(["/usr/local/bin/kubectl", "get", "statefulsets", "-n", namespace, "-o", "jsonpath={.items[*].metadata.name}"], capture_output=True, text=True, check=True)
    return result.stdout.split()

def operate_statefulsets(namespace_list, action, env):
    switch_context(env)
    
    for namespace in namespace_list:
        if action == 'stop':
            scale_statefulsets(namespace, 0)
        elif action == 'start':
            scale_statefulsets(namespace, 1)
        elif action == 'restart':
            scale_statefulsets(namespace, 0)
            scale_statefulsets(namespace, 1)
        else:
            print(f"Unknown action: {action}")
            sys.exit(1)
        operation_results = f"Operation '{action}' completed for environment '{env}'"
    return operation_results
def get_namespaces(env):
    namespaces_map = {
        'qa': ['cnqa01', 'cnqa02', 'cnqa03', 'cnqa04', 'cnqa05', 'cnqacommon'],
        'cnqa01': ['cnqa01'],
        'cnqa02': ['cnqa02'],
        'cnqa03': ['cnqa03'],
        'cnqa04': ['cnqa04'],
        'cnqa05': ['cnqa05'],
        'hotfix': ['hotfix01', 'hotfixcommon'],
        'review': ['gb-review'],
        'pr': ['pr'],
        'kol': ['pr']
    }
    return namespaces_map.get(env, [])

def parse_input(input_str):
    envs = ['cnqa01','cnqa02','cnqa03','cnqa04','cnqa05','qa', 'hotfix', 'review','pr','kol']
    actions = ['restart', 'stop', 'start']

    # Use regex to find env and action in the input string, ignoring case
    env_pattern = re.compile(r'\b(?:' + '|'.join(envs) + r')\b', re.IGNORECASE)
    action_pattern = re.compile(r'\b(?:' + '|'.join(actions) + r')\b', re.IGNORECASE)

    found_envs = env_pattern.findall(input_str)
    found_actions = action_pattern.findall(input_str)

    # Check for multiple or missing envs or actions
    if len(found_envs) != 1:
        return "Error: Must specify exactly one environment (cnqa01,cnqa02,cnqa03,cnqa04,cnqa05,qa, hotfix, review)."
    if len(found_actions) != 1:
        return "Error: Must specify exactly one action (stop, start, restart)."

    env = found_envs[0].lower()
    action = found_actions[0].lower()

    return env, action
#if __name__ == "__main__":
#    if len(sys.argv) != 3:
#        print("Usage: python manage_statefulsets.py <stop/start/restart> <qa/hotfix/review>")
#        sys.exit(1)

#    action = sys.argv[1]
#    env = sys.argv[2]

#    namespace_list = get_namespaces(env)
#    if not namespace_list:
#        print(f"Unknown or empty environment: {env}")
#        sys.exit(1)

 #   info = operate_statefulsets(namespace_list, action, env)
 #   print(info)

