import requests
import json
import sys
import os
import shutil
import re
import time
import subprocess
from datetime import datetime

# GitLab API token
GITLAB_API_TOKEN = "hxwsW-TyexsPcPBwCmLf"

# GitLab project ID (URL-encoded if needed)
PROJECT_ID = "gre-bc%2Fbc-in-k8s"

# Mapping of environments to their corresponding file paths
env_files = {
    "qa": [
        "cnqa01/.gitlab-ci.yml",
        "cnqa02/.gitlab-ci.yml",
        "cnqa03/.gitlab-ci.yml",
        "cnqa04/.gitlab-ci.yml",
        "cnqa05/.gitlab-ci.yml"
    ],
    "hotfix": ["hotfix01/.gitlab-ci.yml"],
    "pr": ["pr/.gitlab-ci.yml"],
    "review": ["review/gb/.gitlab-ci.yml"],
}

def backup_and_update_version(file_path, new_version):
    # Check file_path and execute corresponding curl command
    base_url = "https://gitlab.garena.com/api/v4/projects/gre-bc%2Fbc-in-k8s/repository/files/"
    token = "hxwsW-TyexsPcPBwCmLf"
    base_local_path = "/data/tools/seatalk/server/gm-tools/"

    def execute_curl(remote_path, local_path):
        url = f"{base_url}{remote_path}/raw?ref=master"
        curl_command = f'curl --header "PRIVATE-TOKEN: {token}" "{url}" -o {local_path}'
        subprocess.run(curl_command, shell=True)
        print(f"Executed: {curl_command}")

    if "cnqa01" in file_path:
        remote_path = "gm-tools%2Fcnqa01%2F%2Egitlab-ci%2Eyml"
        local_path = os.path.join(base_local_path, "cnqa01/.gitlab-ci.yml")
        execute_curl(remote_path, local_path)
    elif "cnqa02" in file_path:
        remote_path = "gm-tools%2Fcnqa02%2F%2Egitlab-ci%2Eyml"
        local_path = os.path.join(base_local_path, "cnqa02/.gitlab-ci.yml")
        execute_curl(remote_path, local_path)
    elif "cnqa03" in file_path:
        remote_path = "gm-tools%2Fcnqa03%2F%2Egitlab-ci%2Eyml"
        local_path = os.path.join(base_local_path, "cnqa03/.gitlab-ci.yml")
        execute_curl(remote_path, local_path)
    elif "cnqa04" in file_path:
        remote_path = "gm-tools%2Fcnqa04%2F%2Egitlab-ci%2Eyml"
        local_path = os.path.join(base_local_path, "cnqa04/.gitlab-ci.yml")
        execute_curl(remote_path, local_path)
    elif "cnqa05" in file_path:
        remote_path = "gm-tools%2Fcnqa05%2F%2Egitlab-ci%2Eyml"
        local_path = os.path.join(base_local_path, "cnqa05/.gitlab-ci.yml")
        execute_curl(remote_path, local_path)
    elif "hotfix01" in file_path:
        remote_path = "gm-tools%2Fhotfix01%2F%2Egitlab-ci%2Eyml"
        local_path = os.path.join(base_local_path, "hotfix01/.gitlab-ci.yml")
        execute_curl(remote_path, local_path)
    elif "review" in file_path:
        remote_path = "gm-tools%2Freview%2Fgb%2F%2Egitlab-ci%2Eyml"
        local_path = os.path.join(base_local_path, "review/.gitlab-ci.yml")
        execute_curl(remote_path, local_path)
    elif "pr" in file_path:
        remote_path = "gm-tools%2Fpr%2F%2Egitlab-ci%2Eyml"
        local_path = os.path.join(base_local_path, "pr/.gitlab-ci.yml")
        execute_curl(remote_path, local_path)

    # Backup the file
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    backup_path = f"{file_path}.{timestamp}.bak"
    shutil.copy2(file_path, backup_path)
    print(f"Backup created for {file_path} at {backup_path}")

    # Update the manage_chart_version in the file
    with open(file_path, 'r') as file:
        content = file.read()

    # Use regex to find and replace the version
    updated_content = re.sub(
        r"manage_chart_version: \d+\.\d+\.\d+-GB",
        f"manage_chart_version: {new_version}",
        content
    )

    with open(file_path, 'w') as file:
        file.write(updated_content)
    print(f"Updated manage_chart_version in {file_path} to {new_version}")

#def update_file(file_path, env):
#def update_file(file_path):
#    # Construct GitLab file path
#    gitlab_file_path = f"gm-tools/{file_path}"
#    full_file_path = os.path.join("/data/tools/seatalk/server/gm-tools", file_path)
#    # Read the content of the file into a variable and escape it for JSON
#    with open(full_file_path, 'r') as file:
#        file_content = file.read()
#
#    # Prepare the payload for the curl command
#    payload = {
#        "branch": "master",
#        "commit_message": f"Update {gitlab_file_path} via API",
#        "actions": [
#            {
#                "action": "update",
#                "file_path": gitlab_file_path,
#                "content": file_content
#            }
#        ]
#    }
#
#    # Make the POST request
#    response = requests.post(
#        f"https://gitlab.garena.com/api/v4/projects/{PROJECT_ID}/repository/commits",
#        headers={
#            "Content-Type": "application/json",
#            "PRIVATE-TOKEN": GITLAB_API_TOKEN
#        },
#        data=json.dumps(payload)
#    )
#
#    # Print the response
#    print(f"Response for {gitlab_file_path}: {response.text}")

def update_files(file_paths):
    # List to hold all actions for the commit
    actions = []

    for file_path in file_paths:
        # Construct GitLab file path
        gitlab_file_path = f"gm-tools/{file_path}"
        full_file_path = os.path.join("/data/tools/seatalk/server/gm-tools", file_path)

        # Read the content of the file into a variable
        with open(full_file_path, 'r') as file:
            file_content = file.read()

        # Create an action for this file
        actions.append({
            "action": "update",
            "file_path": gitlab_file_path,
            "content": file_content
        })

    # Prepare the payload for the curl command
    payload = {
        "branch": "master",
        "commit_message": "Update multiple files via API",
        "actions": actions
    }

    # Make the POST request
    response = requests.post(
        f"https://gitlab.garena.com/api/v4/projects/{PROJECT_ID}/repository/commits",
        headers={
            "Content-Type": "application/json",
            "PRIVATE-TOKEN": GITLAB_API_TOKEN
        },
        data=json.dumps(payload)
    )

    # Print the response
    print(f"Response: {response.text}")
    return json.loads(response.text)
def get_file_paths(env):
    return env_files.get(env)

def get_pipeline_status(sha):
    headers = {
        "PRIVATE-TOKEN":GITLAB_API_TOKEN
    }
    pipelines_url = f"https://gitlab.garena.com/api/v4/projects/2625/pipelines?sha={sha}"

    while True:
        response = requests.get(pipelines_url, headers=headers)
        if response.status_code != 200:
            error_message = f"🔴获取 Pipeline 失败: {response.status_code}"
            print(error_message)
            return error_message

        pipelines = response.json()
        print (f"this is {pipelines}")
        if not pipelines:
            error_message = "🔴未找到与该 SHA 关联的 Pipeline,gmtool version似乎没有变化,请检查"
            print(error_message)
            return error_message

        # 获取与 SHA 关联的 Pipeline 状态
        status = pipelines[0]['status']

        if status in ['success', 'failed', 'canceled', 'skipped']:
            break

        print(f"Pipeline 状态: {status}，等待 10 秒后继续检查...")
        time.sleep(10)

    if status == 'success':
        result_message = "gmtool 已更新成🟢 "
        print(result_message)
        return result_message
    else:
        result_message = f"gmtool更新失败,请检,查状态: {status}🔴"
        print(result_message)
        return result_message

#if __name__ == "__main__":
#    if len(sys.argv) != 3:
#        print("Usage: python update_gitlab_files.py <environment> <manage_chart_version>")
#        sys.exit(1)
#
#    environment = sys.argv[1]
#    manage_chart_version = sys.argv[2]
#
#    if environment not in env_files:
#        print(f"Unknown environment: {environment}")
#        sys.exit(1)
#
#    for file_path in env_files[environment]:
#        full_file_path = os.path.join("/data/tools/seatalk/server/gm-tools", file_path)
#        backup_and_update_version(full_file_path, manage_chart_version)
#         update_file(environment)
