import re

def extract_values_v2(text):
    result = []
    
    patterns = {
        'env': r'\[UPDATE ENV\]:\s*(\S+)','gmtool_ver': r'\[GMTool Version\]:\s*(.*)',
        'gmtool_csv': r'\[GMTool CSV\]:\s*(.*)',
        'aos_file': r'\[AOS FILE Path\]:\s*(.*)',
        'aos_build_type': r'\[AOS BUILD TYPE\]:\s*(.*)',
        'ios_file': r'\[IOS FILE Path\]:\s*(.*)',
        'ios_build_type': r'\[IOS BUILD TYPE\]:\s*(.*)',
        'branch': r'\[BRANCH\]:\s*(.*)',
        'chart_ver': r'\[CHART_VERSION\]:\s*(.*)'
#        '[DB UPDATE]': r'\[DB UPDATE\]:\s*(.*)'
#        '[GAME SERVERS]': r'\[GAME SERVERS\]:\s*(.*)',
#        '[PVP SERVERS]': r'\[PVP SERVERS\]:\s*(.*)',
#        '[COMMON SERVERS]': r'\[COMMON SERVERS\]:\s*(.*)'
    }
    
    # 匹配各项内容
    for key, pattern in patterns.items():
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            result.append(f"{key}: {match.group(1).strip()}")
   # 处理 ALL SERVERS
   # all_servers = []
   # if '[GAME SERVERS]' in text:
   #     all_servers.extend(re.search(r'\[GAME SERVERS\]:\s*(.*)', text, re.IGNORECASE).group(1).strip().split(','))
   # if '[PVP SERVERS]' in text:
   #     all_servers.extend(re.search(r'\[PVP SERVERS\]:\s*(.*)', text, re.IGNORECASE).group(1).strip().split(','))
   # if '[COMMON SERVERS]' in text:
   #     all_servers.extend(re.search(r'\[COMMON SERVERS\]:\s*(.*)', text, re.IGNORECASE).group(1).strip().split(','))
   # if all_servers:
   #     result.append(f"all_servers: {','.join(all_servers)}")
   
    return '\n'.join(result)
