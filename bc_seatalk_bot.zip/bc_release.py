import os
import subprocess
import re
import zipfile

pattern = {
    'UPDATE OS': r'UPDATE OS:\s*([\s\S]+?)\n',
    'UPDATE ENV': r'UPDTATE ENV:\s*([\s\S]+?)\n',
    'GMTool UPDATE': r'GMTool UPDATE:\s*([^\n]+)',
    'GMTool CSV': r'GMTool CSV:\s*([^\n]+)',
    'GMTool CSV MD5': r'GMTool CSV MD5:\s*([^\n]+)',
    'CDN UPDATE': r'CDN UPDATE:\s*([^\n]+)',
    'AOS FILE Path': r'AOS FILE Path:\s*([^\n]+)',
    'AOS MD5': r'AOS MD5:\s*([^\n]+)',
    'AOS BUILD TYPE': r'AOS BUILD TYPE:\s*([^\n]+)',
    'IOS FILE Path': r'IOS FILE Path:\s*([^\n]+)',
    'IOS MD5': r'IOS MD5:\s*([^\n]+)',
    'IOS BUILD TYPE': r'IOS BUILD TYPE:\s*([^\n]+)',
    'DB UPDATE': r'DB UPDATE:\s*([^\n]+)',
    'GB DB Script Path': r'GB DB Script Path :\s*([^\n]+)',
    'GB DB Script MD5': r'GB DB Script MD5:\s*([^\n]+)',
    'SERVRE UPDATE': r'SERVRE UPDATE:\s*([^\n]+)',
    'SERVER MODULE': r'SERVER MODULE:\s*([^\n]+)',
    'SERVER HELM CHART UPDATE': r'SERVER HELM CHART UPDATE :\s*([^\n]+)',
}

# 函数：上传到 OBS
def upload_to_obs(local_path, obs_path, recursive=False):
    command = f'./data/tools/obs/obsutil_linux_amd64_5.5.9/obsutil cp {local_path} {obs_path} -f -r'
    subprocess.run(command, shell=True)
class ReleaseGenerator:
    def __init__(self,text):
        self.text = text
        self.base_res_upload_dir = "/data/home/bc_build/"
        self.base_des_upload_dir = "obs://dl-bc-cdn-garenanow-com/"
        self.base_aos_purge_url_test = "https://dl.bc.cdn.garenanow.com/test/android/"
        self.base_ios_purge_url_test = "https://dl.bc.cdn.garenanow.com/test/ios/"
    def extract_value(self,pattern_key):
        return re.search(pattern[pattern_key], self.text).group(1)

    def generate_release_confirm_content(self):
        # Implementation of extract_value method
        update_os_value = self.extract_value("UPDATE OS")
        update_env_value = self.extract_value("UPDATE ENV")
        gmtool_update_value = self.extract_value("GMTool UPDATE")
        gmtool_csv_value = self.extract_value("GMTool CSV")
        gmtool_csv_md5_value = self.extract_value("GMTool CSV MD5")
        cdn_update_value = self.extract_value("CDN UPDATE")
        aos_file_path_value = self.extract_value("AOS FILE Path")
        aos_md5_value = self.extract_value("AOS MD5")
        aos_build_type_value = self.extract_value("AOS BUILD TYPE")
        ios_file_path_value = self.extract_value("IOS FILE Path")
        ios_md5_value = self.extract_value("IOS MD5")
        ios_build_type_value = self.extract_value("IOS BUILD TYPE")
        db_update_value = self.extract_value("DB UPDATE")
        db_script_path_value = self.extract_value("GB DB Script Path")
        db_script_md5_value = self.extract_value("GB DB Script MD5")
        server_update_value = self.extract_value("SERVRE UPDATE")
        server_module_value = self.extract_value("SERVER MODULE")
        helm_chart_update_value = self.extract_value("SERVER HELM CHART UPDATE")
        aos_purge_url_test = self.base_aos_purge_url_test + aos_build_type_value + "/patch_info.json"
        ios_purge_url_test = self.base_ios_purge_url_test + ios_build_type_value + "/patch_info.json"
        aos_cdn_upload_dir_test = self.base_aos_purge_url_test + aos_build_type_value + "/"
        ios_cdb_upload_dir_test = self.base_ios_purge_url_test + ios_build_type_value + "/"
        gmtool_upload_resource = self.base_res_upload_dir + gmtool_csv_value
        release_confirm_content = f'''
        gmtool:{gmtool_update_value}
        server:{server_update_value}
        cdn:{cdn_update_value}
        os:{update_os_value}
        env:{update_env_value}
        gmtool csv: {gmtool_csv_value}
        aostype:{aos_build_type_value}
        iostype:{ios_build_type_value}
        afile:{ios_file_path_value}
        ifile:{aos_file_path_value}
        server chat:{helm_chart_update_value}
        '''
        result_dict = {
        "update_os_value":update_os_value,
        "update_env_value":update_env_value, 
        "gmtool_update_value":gmtool_update_value, 
        "gmtool_csv_value":gmtool_csv_value, 
        "gmtool_csv_md5_value":gmtool_csv_md5_value,
        "cdn_update_value":cdn_update_value, 
        "aos_file_path_value":cdn_update_value,  
        "aos_md5_value":aos_md5_value,
        "aos_build_type_value":aos_build_type_value,
        "ios_file_path_value":ios_file_path_value, 
        "ios_md5_value":ios_md5_value, 
        "ios_build_type_value":ios_build_type_value,
        "db_update_value":db_update_value, 
        "db_script_path_value":db_script_path_value,  
        "db_script_md5_value":db_script_md5_value,  
        "server_update_value":server_update_value,  
        "server_module_value":server_module_value,  
        "helm_chart_update_value":helm_chart_update_value,  
        "aos_purge_url_test":aos_purge_url_test, 
        "ios_purge_url_test":ios_purge_url_test,  
        "aos_cdn_upload_dir_test":aos_cdn_upload_dir_test,
        "ios_cdb_upload_dir_test":ios_cdb_upload_dir_test,
        "gmtool_upload_resource":gmtool_upload_resource
        }
        return release_confirm_content,result_dict

#release_generator = ReleaseGenerator(text)

# Call the method to generate the release content
#release_confirm_content_string, release_confirm_content_dict = release_generator.generate_release_confirm_content()
# Print or use the string and dictionary as needed

